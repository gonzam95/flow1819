%--- defino largueros de chapas intermedias ---
xy=max(ni);
xce=zeros(ce-1,xy+2);
yce=zeros(ce-1,xy+2);
ace=zeros(ce-1,xy+2);
ni1=[0 ni];
ni2=n;
for i=1:ce-1
    n1=div1(1,i);
    n2=div2(1,i);
    nc=ni(1,i)+2;
    xce(i,1)=x0(1,n1);
    xce(i,nc)=x0(1,n2);
    yce(i,1)=y0(1,n1);
    yce(i,nc)=y0(1,n2);
    ace(i,1)=A(1,n1);
    ace(i,nc)=A(1,n2);
    if ni(1,i)~=0
        for j=1:ni(1,i)
            ni2=ni2+1;
            xce(i,j+1)=x0(1,ni2);
            yce(i,j+1)=y0(1,ni2);
            ace(i,j+1)=A(1,ni2);      
        end
    end
end
%--- Calculo area barrida para cada chapa ---
Ab=zeros(1,nq);
x2=[x0(1,n) x0 x0];
y2=[y0(1,n) y0 y0];
bi=zeros(1,nq);
for i=1:n
    base=((y2(1,i+1)-y2(1,i))^2+(x2(1,i+1)-x2(1,i))^2)^(1/2);
    a=((x2(1,i+1))^2+(y2(1,i+1))^2);
    b=((x2(1,i))^2+(y2(1,i))^2)^(1/2);
    h=b*sin(acos((a-b^2-base^2)/(-2*b*base)));
    Ab(1,i)=base*h/2;
    bi(1,i)=base;
end
%--- para chapas intermedias ---
Abmult=ones(1,nq);
n1=n;
for i=1:ce-1
    for j=1:ni(1,i)+1
        n1=n1+1;
        x9=[xce(i,j) xce(i,j+1)];
        y9=[yce(i,j) yce(i,j+1)];
        base=((y9(1,2)-y9(1,1))^2+(x9(1,2)-x9(1,1))^2)^(1/2);
        a=((x9(1,2))^2+(y9(1,2))^2);
        b=((x9(1,1))^2+(y9(1,1))^2)^(1/2);
        h=b*sin(acos((a-b^2-base^2)/(-2*b*base)));
        Ab(1,n1)=base*h/2;
        bi(1,n1)=base;
    end
end