
%Momentos de inercia
Lprop=zeros(n,2); %Primer columna area total de la seccion, 2� momento de inercia
for k=1:n
    Ll=Dimensiones(k,:);
    Lt=Espesores(k,:);
    La=Ll.*Lt; %producto de longitud y espesor para cada capa
    Lprop(k,1)=sum(La); %suma de los productos = Area de la seccion
    Lcg=(La(1)*Ll(2)+La(2)*Ll(2)/2)/Lprop(k,1); %calculo cg de la seccion
    Lprop(k,2)=(Ll(1)*Lt(1)^3/12+La(1)*(Ll(2)-Lcg)^2)+(Lt(2)*Ll(2)^3/12+La(2)*(Lcg-Ll(2)/2)^2)+(Ll(3)*Lt(3)^3/12+La(3)*Lcg^2);
    % Momento de inercia (considera momentos propios y steiner)
end

switch Pref.LongRef
    case 'Maxima', auxlong = max(long);
    case 'Minima', auxlong = min(long);
    case 'Referencia', auxlong = input(' Ingrese longitud de referencia para carga pandeo: ');
end
        
lamp = sqrt(pi^2*Eco/(Sigmaco/2));

for k = 1:n
    
    ro = sqrt(Lprop(k,2)/Lprop(k,1));
    lam = auxlong/ro;
    
    if lam >= lamp
        Sigmacr(k) = pi^2*Eco/lam^2;
        
    elseif (lam>20)&&(lam<lamp)
        Sigmacr(k) = Sigmaco - Sigmaco^2*lam^2/(4*pi^2*Eco);
        
    else
        Sigmacr(k) = Sigmaco;
        
    end
    
    if PCritica(k)~=0
        Sigmacr(k) = PCritica(k)/LProp(k,1);
    end
    
end