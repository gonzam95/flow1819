%% Proceso de optimizacion

% NonZero;
clear T
back=0;

if nOptim2==0
    nri = 1;
    nrf = length(nse);
else
    nri = nOptim2;
    nrf = nOptim2;
end

for u=nri:nrf
    disp(' ')
    disp(['--- Seccion ' num2str(u) ' ---'])
    disp(' ')
    
    T.Lar = (1:n)';


    T.A(:,1)=As(u,:)'; %Areas
    T.P(:,1)=allR(2,:,u)'; %cargas sobre larguero
    T.Psig(:,1)=allS(2,:,u)'; %para saber si es carga de traccion o comp
    
    if T.A == 0
        T.S = 0;
    else
        T.S = T.P./T.A; %tensiones
    end
    
    no=length(T.S); %Cantidad de largueros
    T.Scr=zeros(no,1); %tensiones maximas

    for i=1:no
        if T.Psig(i)>0
            T.Scr(i,1) = Sigmaco; %admisible
        else
            if exist('Sigmacr','var')
                T.Scr(i,1) = Sigmacr(i); %critica por pandeo
            else 
                T.Scr(i,1) = Sigmaco;
                disp(' No se econtraron secciones sobre las que calcular tensiones criticas')
                disp('de pandeo, por lo que se muestra la tension admisible en todos los casos')
            end
        end
    end

    T.Q = allq(2,:,u)'; 
    T.t = Ts(u,:)'; %espesores de chapas
    T.tau = abs(T.Q)./T.t; %tensiones de corte en chapas
    T.Sq = ones(length(T.tau),1)*Tauch; %tension admisible de corte
    T.ch = (1:length(T.Q))';

    mo = length(T.Q);

    if mo>no
        for i=no+1:mo
            T.Lar(i,1) = 0 ;
            T.A(i,1) = 0;
            T.P(i,1) = 0;
            T.S(i,1) = 0;
            T.Scr(i,1) = 0;
        end
    end
    
    %% Criterio de visualizacion de tensiones
    switch Pref.TensOpt
        case 'Absoluto', 
        case 'Diferencia', T.S = T.Scr-T.S;
        case 'Relacion', T.S = T.S./T.Scr;
    end

    switch Pref.TensOpt
        case 'Absoluto', 
        case 'Diferencia', T.tau = T.Sq-T.tau;
        case 'Relacion', T.tau = T.tau./T.Sq;
    end
    
    %% Tabla de resultados
    
    Ta = table(T.Lar,T.A,T.S,T.Scr,T.ch,T.t,T.tau,T.Sq,'VariableNames',{'Larguero','Area','Tension','T_Limite','Chapa','Espesor','TensionQ','TLimite'});
    disp(Ta);
    clear T Ta no mo 

end

clear nri nrf


switch auxCambiar
    
    case 1 %cambiar areas
        
        
        disp(' Para volver atras ingrese 0 (cero)')
        no = input('Ingrese el numero de larguero que desea modificar: ','s');
        disp(' ')
        no=str2num(no);
        if no==0
            back=1;
        else
            mo = input('Ingrese nuevo valor: ');
        end
        
    case 2 %cambiar espesores
        disp(' Para volver atras ingrese 0 (cero)')
        no = input('Ingrese el numero de chapa que desea modificar: ','s');
        disp(' ')
        no=str2num(no);
        if no==0
            back=1;
        else
            mo = input('Ingrese nuevo valor: ');
        end
        
    case 3 % cambiar secciones
      if MSecciones==1
        T.Larguero=nnc;
        cont=0;
        for i=1:length(nnc1)
        %decirle a los vectores que formaran la tabla que eliminen la fila
        %correspondiente a largueros cuya area=0
            if nnc1(i,1)~=0
               cont=cont+1;
               T.Sec(cont,1)=Seccion(i,1);
               T.Dim(cont,:)=Dimensiones(i,:);
               T.Esp(cont,:)=Espesores(i,:);
               T.Area(cont,1)=Areas(i,1);
               T.Jz(cont,1)=Jz(i,1);
               T.Scr(cont,1)=Sigmacr(i,1);
           end
        end
        T=table(T.Larguero,T.Sec,T.Dim,T.Esp,T.Area,T.Jz,T.Scr,'VariableNames',{'Larguero','Seccion','Dimensiones','Espesores','Areas','Jz','Sigmacr'});
        disp(T)
        
        % En este proceso se asume que todo los largueros ingresado
        % contienen el mismo tipo de larguero, por lo que se toma el tipo
        % de perfil del primer larguero y se aplica el mismo a todos los
        % demas
        
        disp(' Para volver atras ingrese 0 (cero)')
        disp('Ingrese los largueros cuya seccion desea modificar,')
        lar = input('dejando un espacio entre cada numero: ','s');
        disp(' ')
        if str2num(lar)==0
            back=1;
        else
            mdo = input('Ingrese las dimensiones (dejando un espacio entre medio): ','s');
            mto = input('Ingrese los espesores (dejando un espacio entre medio): ','s');
            lar = str2num(lar);
            mdo = str2num(mdo); 
            mto = str2num(mto); 
            asec = Seccion(lar(1));
            if strcmp(asec,'L')
                mdo(3)=0; % si la seccion es L completo el vector
                mto(3)=0; % con la 3 comp = 0
            end
            mdo=mdo(1:3); mto=mto(1:3); %me quedo con solo las 3 primeras componenetes
            for i=1:length(lar)
                k1=lar(i);
                Seccion(k1) = asec;
                Dimensiones(k1,:) = mdo;
                Espesores(k1,:) = mto;

            end

            switch Pref.TensPcr
                case 'Local'
                    PandeoL; %calculo props geom y SigmaCr
                case 'Columna'
                    PandeoC
            end
            
            Areas=Lprop(:,1); %Lprop se calcula en PandeoL;
            Jz=Lprop(:,2);
        end
      end %end if MSecciones
        
         

end %end Switch

if back==1
    Optimizar;
else
    if nOptim==0
        nri = 1;
        if nse==1
            nrf=2;
        else
            nrf = nse;
        end
    else
        nri = nOptim;
        nrf = nOptim;
    end

    switch auxCambiar
        case {1,2}
            for u=nri:nrf
                if auxCambiar==1
                    As(u,no) = mo;
                elseif auxCambiar==2
                    Ts(u,no) = mo;
                end
            end

        case 3
            for u=nri:nrf
               for j=1:length(lar)
                   k1=lar(j);
                   As(u,k1) = Areas(k1,1); 
               end
            end
    end
    Optim = 1;
    Calculos;
end    

    
    
    
    
    
    
