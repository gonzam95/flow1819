%% Nuevos valores
if chooseCarga==1 
    disp(' ')
    disp('--------------------') 
    disp('   Estado de Carga')
    disp('--------------------')
    Pce=zeros(nse,4); %vector de cargas externas por estacion [Px distY Py distX]
    Mt=zeros(nse,1); %vector de momento torsor por estacion
    for i=1:nse
      disp(' ')
      disp(['Estacion ' num2str(i)])
      disp(' ')
      Pce(i,1)=input('Valor de Px: '); %carga positiva a la derecha
      if Pce(i,1)~=0
          Pce(i,2)=input('Distancia en Y de Px: ');
      end
      Pce(i,3)=input('Valor de Py: '); %carga positiva para arriba
      if Pce(i,3)~=0
          Pce(i,4)=input('Distancia en X de Py: ');
      end
      if i==1
          Mfx = input('Momento flector en X: ');
          Mfy = input('Momento flector en Y: ');
      end
      %Mt(i,1)=input('Momento torsor: '); %momentos positivos -> sentido horario
      save('Flow');
    end
    disp(' ')
    save('Flow');
    if Calculado==0
        Inicio;
    elseif Calculado==1
        PostCalculos;
    end;
    
%% Cambiar valores
elseif chooseCarga==2
    disp(' ')
    disp('--------------------') 
    disp('   Estado de Carga')
    disp('--------------------')
    disp(' ')
    disp(' 1-Cargas horizontales (Px)')
    disp(' 2-Cargas verticales (Py)')
    disp([' 3-Momento flector en X (Mfx): ' num2str(Mfx)])
    disp([' 4-Momento flector en Y (Mfy): ' num2str(Mfy)])
    
    % disp(' 3-Momentos torsores')
    disp(' 0-Atras')
    disp(' ')
    changeCarga=input('Elija una opci�n: ');
    disp(' ')
    switch changeCarga
        case 1
            disp('Valores de Px')
            disp(transpose(Pce(:,1)))
            disp('Distancias en Y de Px')
            disp(transpose(Pce(:,2)))
            changep=input('Cambiar valores de estaci�n n�: ','s');
            if isempty(changep)==0
                if strcmp(changep,'all') %si ingreso all
                    Pts=zeros(nse,2);
                    for i=1:nse
                        disp(['Estacion ' num2str(i)])
                        Pts(i,1)=input('Valor de Px: ');
                        if Pts(i,1)~=0
                            Pts(i,2)=input('Distancia en Y de Px: ');
                        end
                    end
                    Pce(:,1)=Pts(:,1);
                    Pce(:,2)=Pts(:,2);
                else
                    Pce(changep,1)=input('Valor de Px: ');
                    if Pce(changep,1)~=0
                        Pce(changep,2)=input('Distancia en Y de Px: ');
                    end
                end
            end
            
        case 2
            disp('Valores de Py')
            disp(transpose(Pce(:,3)))
            disp('Distancias en X de Py')
            disp(transpose(Pce(:,4)))
            changep=input('Cambiar valores de estaci�n n�: ','s');
            if isempty(changep)==0
                if strcmp(changep,'all') %si ingreso all
                    Pts=zeros(nse,2);
                    for i=1:nse
                        disp(['Estacion ' num2str(i)])
                        Pts(i,1)=input('Valor de Py: ');
                        if Pts(i,1)~=0
                            Pts(i,2)=input('Distancia en X de Py: ');
                        end
                    end
                    Pce(:,3)=Pts(:,1);
                    Pce(:,4)=Pts(:,2);
                else
                    Pce(changep,3)=input('Valor de Py: ');
                    if Pce(changep,3)~=0
                        Pce(changep,4)=input('Distancia en X de Py: ');
                    end
                end
            end
            
            
%         case 3
%             disp('Valores de momento torsor')
%             disp(transpose(Mt));
%             changemt=input('Cambiar valor de estaci�n n�: ','s');
%             tf=strcmp(changemt,'all');
%             if tf==1
%                 Mt=zeros(nse,1);
%                 for i=1:nse
%                     disp(['Estaci�n ' num2str(i)])
%                     Mt(i,1)=input('Valor de Mt: ');
%                 end
%             elseif tf==0
%                 changemt=str2double(changemt);
%                 Mt(changemt,1)=input('Valor de Mt: ');
%             end
            
        case 3
            Mfx = input(' Nuevo valor de momento flector en X: ');
            
        case 4
            Mfy = input(' Nuevo valor de momento flector en Y: ');

            
    end
    disp(' ')
    clear changep changemt Pts tf
    save('Flow');
    if changeCarga==0
        if Calculado==0
            Inicio;
        else
            PostCalculos;
        end
    else MenuCarga;
    end
end

 