
%--- defino secciones ahusadas ---

if nse==1
    nesp=1;
else
    nesp=nse-1;
end

RQ=zeros(nq,2*nesp);
RS=zeros(nt,2*nesp);
RH=zeros(nt,2*nesp);
RV=zeros(nt,2*nesp);    
RdS=zeros(nesp,nt);
        
    %--- defino matrices con todos los resultados ---
    kr=0;
    colname=zeros(1,nse);
    rowname=zeros(nse,1);
    for i=1:nse
        rowname(i,1)=i;
    end
    for i=1:nesp
        RdS(i,:)=alldS(1,:,i);
        for j=1:2
            kr=kr+1;
            RQ(:,kr)=allq(j,:,i);
            RS(:,kr)=allS(j,:,i);
            RH(:,kr)=allH(j,:,i);
            RV(:,kr)=allV(j,:,i);
            colname(1,kr)=i+j-2;
        end
    end
    RdS=RdS';
    RR = sqrt(RS.^2+RH.^2+RV.^2);
    nRR = size(RR);
    for i = 1:nRR(1)
        for j = 1:nRR(2)
            if RS(i,j)~=0
                RR(i,j) = RR(i,j)*RS(i,j)/abs(RS(i,j));
            end
        end
    end
    
    
HayTensiones=1;
%--- tablas de tensiones ---
try
clear T
no = size(RS);
T=zeros(size(RS));
auxA = [colname(2:end) colname(end)];
for i=1:no(1)
    for j=1:no(2)
        k = auxA(j);
        if RS(i,j)>0
            switch Pref.Tensiones
                case 'Absoluto', T(i,j) = RR(i,j)/As(k,i);
                case 'Diferencia', T(i,j) = Sigmaco-RR(i,j)/As(k,i);
                case 'Relacion', T(i,j) = (RR(i,j)/As(k,i))/Sigmaco;
            end
        else 
            if exist('Sigmacr','var')
                switch Pref.Tensiones
                    case 'Absoluto', T(i,j) = abs(RR(i,j)/As(k,i));
                    case 'Diferencia', T(i,j) = Sigmacr(i)-abs(RR(i,j)/As(k,i));
                    case 'Relacion', T(i,j) = (abs(RR(i,j)/As(k,i)))/Sigmacr(i);
                end
            else
                switch Pref.Tensiones
                    case 'Absoluto', T(i,j) = abs(RR(i,j)/As(k,i));
                    case 'Diferencia', T(i,j) = Sigmaco-abs(RR(i,j)/As(k,i));
                    case 'Relacion', T(i,j) = (abs(RR(i,j)/As(k,i)))/Sigmaco;
                end
            end
        end
    end
end

f1p=uipanel('Title','T Axil','TitlePosition','centertop','FontSize',10,'Units','normalized','Position',[0 2/3 0.5 1/3]);
if not(exist('Sigmacr','var'))
    Sigmacr=zeros(no(1),1);
end
f1data = [ones(no(1),1)*Sigmaco Sigmacr T]; 
f1t=uitable('Parent',f1p,'Data',f1data,'Units','normalized','Position',[0 0 1 1],'ColumnName',{'Sadm','Scr',colname});

clear T f1p f1data f1t

no = size(RQ);
T=zeros(size(RQ));
for i=1:no(1)
    for j=1:no(2)
        k = auxA(j);
        switch Pref.Tensiones
            case 'Absoluto', T(i,j) = abs(RQ(i,j)/Ts(k,i));
            case 'Diferencia', T(i,j) = Tauch-abs(RQ(i,j)/Ts(k,i));
            case 'Relacion', T(i,j) = (abs(RQ(i,j)/Ts(k,i)))/Tauch;
        end
    end
end

f1p=uipanel('Title','T Corte','TitlePosition','centertop','FontSize',10,'Units','normalized','Position',[0.5 2/3 0.5 1/3]);
f1data = [ones(no(1),1)*Tauch T]; 
f1t=uitable('Parent',f1p,'Data',f1data,'Units','normalized','Position',[0 0 1 1],'ColumnName',{'Tadm',colname});

clear T f1p f1data f1t
catch ME
    disp(' ')
    disp(' No se pueden mostrar las tablas de tensiones.')
    disp(' Surgio el siguiente error')
    disp(ME.message)
    HayTensiones=0;
end
switch HayTensiones
    case 1
        Pos1 = [0 1/3 1/3 1/3]; % posicion de panel Q
        Pos2 = [0 0 1/3 1/3]; % posicion de panel S
        Pos3 = [2/3 1/3 1/3 1/3]; % posicion de panel dS/a
        Pos4 = [1/3 0 1/3 1/3]; % posicion de panel H
        Pos5 = [2/3 0 1/3 1/3]; % posicion de panel V
        Pos6 = [1/3 1/3 1/3 1/3]; % posicion de panel R
    case 0
        Pos1 = [0 0 1/3 0.5]; % posicion de panel Q
        Pos2 = [0 0.5 1/3 0.5]; % posicion de panel S
        Pos3 = [2/3 0 1/3 0.5]; % posicion de panel dS/a
        Pos4 = [1/3 0.5 1/3 0.5]; % posicion de panel H
        Pos5 = [2/3 0.5 1/3 0.5]; % posicion de panel V
        Pos6 = [1/3 0 1/3 0.5]; % posicion de panel R
end
%--- tablas de esfuerzos---
% f1=subplot(3,4,[2,3,4]);
f1p1=uipanel('Title','Q','TitlePosition','centertop','FontSize',10,'Units','normalized','Position',Pos1);%dist abajo dist izq ancho alto
f1p2=uipanel('Title','S','TitlePosition','centertop','FontSize',10,'Units','normalized','Position',Pos2);%dist abajo dist izq ancho alto
% f1p1txt=uicontrol('Style','text','String','Estacion N�','Position',[0 0 15 15],'BackgroundColor','white','FontSize',8);
f1t1=uitable('Parent',f1p1,'Data',RQ,'Units','normalized','Position',[0 0 1 1],'ColumnName',colname);
f1t2=uitable('Parent',f1p2,'Data',RS,'Units','normalized','Position',[0 0 1 1],'ColumnName',colname);
% f1p2txt=uicontrol('Style','text','String','Estacion N�','Position',[nt1*3/2 447 100 20],'BackgroundColor','white','FontSize',8);
f1p5=uipanel('Title','deltaS/a','TitlePosition','centertop','FontSize',10,'Units','normalized','Position',Pos3);
f1t5=uitable('Parent',f1p5,'Data',RdS,'Units','normalized','Position',[0 0 1 1]);
% f1p5txt=uicontrol('Style','text','String','Seccion N�','Position',[15 15 20 80],'BackgroundColor','white','FontSize',8);
f1p6=uipanel('Title','N','TitlePosition','centertop','FontSize',10,'Units','normalized','Position',Pos6);
f1t6=uitable('Parent',f1p6,'Data',RR,'Units','normalized','Position',[0 0 1 1],'ColumnName',colname);



%--- tablas para vigas ahusadas ---

f1p3=uipanel('Title','H','TitlePosition','centertop','FontSize',10,'Units','normalized','Position',Pos4);%dist abajo dist izq ancho alto
f1p4=uipanel('Title','V','TitlePosition','centertop','FontSize',10,'Units','normalized','Position',Pos5);%dist abajo dist izq ancho alto
% f1p3txt=uicontrol('Style','text','String','Estacion N�','Position',[nt1*3-70 447 100 20],'BackgroundColor','white','FontSize',8);
f1t3=uitable('Parent',f1p3,'Data',RH,'Units','normalized','Position',[0 0 1 1],'ColumnName',colname);
f1t4=uitable('Parent',f1p4,'Data',RV,'Units','normalized','Position',[0 0 1 1],'ColumnName',colname);
% f1p4txt=uicontrol('Style','text','String','Estacion N�','Position',[nt1*4-35 447 100 20],'BackgroundColor','white','FontSize',8);

clear f1 f1p1 f1p2 f1t1 f1t2 f1p5 f1t5 f1p3 f1p4 f1t3 f1t4

%--- tablas de datos geometricos ---
f2=figure;
% subplot(4,1,1)
Rgeom=[allCg'; allJx'; allJy'; allJxy';];
f2t1=uitable('Data',Rgeom,'Units','normalized','Position',[0 0.75 1 0.25],'RowName',{'Cgx','Cgy','Jx','Jy','Jxy'});%,'RowName',rowname);

clear f2 f2t1

GrafO=1;
Grafico;
hold off
PostCalculos;