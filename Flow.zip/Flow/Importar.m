
try
    n=xlsread('Importar.xlsx',1,'E4:E4');
    nse=xlsread('Importar.xlsx',1,'E2:E2');
    ce=xlsread('Importar.xlsx',1,'E3:E3');
    if ce>1 
        numero=12+ce-2;
        Letras;
        rango=strcat('L3:',letra,'3');
        ni=xlsread('Importar.xlsx',1,rango);
        numero=11+ce-2;
        Letras;
        rango=strcat('K6:',letra,'6');
        div1=xlsread('Importar.xlsx',1,rango);
        rango=strcat('K7:',letra,'7');
        div2=xlsread('Importar.xlsx',1,rango);
    end
    numero=n+ce-1+sum(ni)+9;
    Letras;
    if nse==1
        aux=13;
    else
        aux=12;
    end
    rango=strcat('J14:',letra,num2str(nse+aux));
    Ts=xlsread('Importar.xlsx',1,rango);
    rango=strcat('B8:E',num2str(nse+aux-6));
    Pce=xlsread('Importar.xlsx',1,rango);
    
    Mfx = xlsread('Importar.xlsx',1,'F8:F8');
    Mfy = xlsread('Importar.xlsx',1,'G8:G8');
    numero=n+sum(ni)+4;
    Letras;
    rango=strcat('C5:',letra,num2str(nse+4));
    Xs=xlsread('Importar.xlsx',2,rango);
    Ys=xlsread('Importar.xlsx',3,rango);
    if nse==1
        aux=4;
    else
        aux=3;
    end
    rango=strcat('C5:',letra,num2str(nse+aux));
    As=xlsread('Importar.xlsx',4,rango);
    if nse==1
        numero=10+nse;
    else
        numero=9+nse;
    end
    Letras;
    rango=strcat('K10:',letra,'10');
    long=xlsread('Importar.xlsx',1,rango);
    long2=zeros(1,nse);
    z=zeros(1,nse);
    for i=2:nse
        long2(1,i-1)=long(1,i-1);
        z(1,i)=sum(long2);
    end
    disp(' ')
    disp('--- Datos cargados ---')
    disp(' ')
    
catch ME
    disp('Surgio un error al intentar leer los datos')
    disp(ME.message)

end

Inicio;
