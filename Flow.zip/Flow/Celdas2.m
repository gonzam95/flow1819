cnq=n+ce-1+sum(ni); %cant de chapas
nt=n+sum(ni); %cant largueros
%--- defino celdas ---
c1=zeros(ce,nq); %para guardar chapas de la celda
c2=zeros(ce,nt); %para guardar largueros de la celda
nce1=zeros(1,ce); %cantidad de chapas/largueros por celda
%--- celda 1 ---
for i=1:div1(1,1) %celdas y largueros iniciales
    c1(1,i)=i;
    c2(1,i)=i;
    k=i;
    k2=i;
end
for i=div2(1,1)+1:n %celdas finales
    k=k+1;
    c1(1,k)=i;
end
for i=1:ni(1,1) %largueros intermedios
    k2=k2+1;
    c2(1,k2)=n+i;
end
for i=div2(1,1):n %lasrgueros finales
    k2=k2+1;
    c2(1,k2)=i;
end
for i=1:ni(1,1)+1 %celdas intermedias
    k=k+1;
    c1(1,k)=n+i;
end
nce1(1,1)=k;
%--- ultima celda ---
k=0;
k2=0;
for i=div1(1,ce-1)+1:div2(1,ce-1) %celdas periferia
    k=k+1;
    c1(ce,k)=i;
end
for i=div1(1,ce-1):div2(1,ce-1) %largueros periferia
    k2=k2+1;
    c2(ce,k2)=i;
end
for i=1:ni(1,ce-1)+1 %celda intermedia
    k=k+1;
    c1(ce,k)=nt-ni(1,ce-1)+ce-2+i;
end
k3=k2+ni(1,ce-1)+1;
for i=1:ni(1,ce-1) %largueros intermedios
    k2=k2+1;
    k3=k3-1;
    c2(ce,k3)=nt-sum(1,ce-1)+i+(ce-4);
end
nce1(1,ce)=k;
%--- celdas intermedias ---
n11=[0 ni];
for j=2:ce-1
    n1=n;
    n3=n;
    k=0;
    k2=0;
  if div1(1,j-1)~=div1(1,j)
      k2=0;
    for i=div1(1,j-1)+1:div1(1,j) %celdas periferia sup
        k=k+1;
        c1(j,k)=i;
    end
  end
  if div2(1,j)~=div2(1,j-1) 
    for i=div2(1,j)+1:div2(1,j-1) %celdas periferia inf
        k=k+1;
        c1(j,k)=i;
    end
  end
  if j==2  
      n1=n1+n11(1,j-1);
  else
      n1=n1+n11(1,j-1)+1; %sumo uno porque hay siempre una chapa mas que largueros=ni(1,j-1)
  end
  n2=n1;
  n3=n3+n11(1,j-1);
    for i=1:ni(1,j-1)+1 %celdas intermedias izq
        k=k+1;
        n2=n2+1;
        c1(j,k)=n2;
    end
    for i=1:ni(1,j)+1 %celdas intermedias der
        k=k+1;
        n2=n2+1;
        c1(j,k)=n2;
    end
    if ni(1,j-1)~=0 %largueros intermedios izq
        k3=n3+ni(1,j-1)+1;
        for i=1:ni(1,j-1)
            k2=k2+1;
            n3=n3+1;
            k3=k3-1;
            c2(j,k2)=k3;
        end
    end
    k2=k2+1;
    c2(j,k2)=div1(1,j-1);
    if div1(1,j-1)~=div1(1,j)
        k2=k2-1;
        for i=div1(1,j-1):div1(1,j) %largueros periferia sup
            k2=k2+1;
            c2(j,k2)=i;
        end
    end
    if ni(1,j)~=0 %largueros intermedios der
        for i=1:ni(1,j)
            k2=k2+1;
            n3=n3+1;
            c2(j,k2)=n3;
        end
    end
    k2=k2+1;
    c2(j,k2)=div2(1,j-1);
    if div2(1,j)~=div2(1,j-1)
        k2=k2-1;
        for i=div2(1,j):div2(1,j-1) %largueros periferia inf
        k2=k2+1;
        c2(j,k2)=i;
        end
    end
    nce1(1,j)=k;    
end
%--- calculo el giro ---
Bfi=zeros(ce,nq);
Acelda=zeros(1,ce);
for i=1:ce %determino area de cada celda
    xce2=zeros(1,nce1(1,i)+1);
    yce2=zeros(1,nce1(1,i)+1);
    ace2=zeros(1,nce1(1,i)+1);
    for j=1:nce1(1,i)
        num2=c2(i,j);
        xce2(1,j)=X(2,num2);
        yce2(1,j)=Y(2,num2);
        ace2(1,j)=A(1,num2);
    end     
    Atce=sum(ace2);
    Cgce=[ace2*transpose(xce2)/Atce ace2*transpose(yce2)/Atce];

    for j=1:nce1(1,i)
        xce2(1,j)=xce2(1,j)-Cgce(1,1);
        yce2(1,j)=yce2(1,j)-Cgce(1,2);
    end
    xce2(1,nce1(1,i)+1)=xce2(1,1);
    yce2(1,nce1(1,i)+1)=yce2(1,1);
    ace2(1,nce1(1,i)+1)=ace2(1,1);
    Abce2=zeros(1,nce1(1,i));
    for j=1:nce1(1,i)
        base=((yce2(1,j+1)-yce2(1,j))^2+(xce2(1,j+1)-xce2(1,j))^2)^(1/2);
        a=((xce2(1,j+1))^2+(yce2(1,j+1))^2);
        b=((xce2(1,j))^2+(yce2(1,j))^2)^(1/2);        
        h=b*sin(acos((a-b^2-base^2)/(-2*b*base)));
        Abce2(1,j)=base*h/2;
    end
    Acelda(1,i)=sum(Abce2);
end
ni2=[0 ni];
ni3=n;
for i=1:ce %ecuacion de giro de cada celda
    if i>1
        ni3=ni3+ni2(1,i-1);
    end
    for j=1:nce1(1,i)
        ajuste=1;
        k=c1(i,j);
        if i>1
%             if (k>ni3)&&(k<=ni3+ni(1,i-1)+1)
%                  ajuste=-1;
%             end
            if Bfi(i-1,k)>0
                ajuste=-1;
            end
        end
        Bfi(i,k)=bi(1,k)/(Ts(1,k)*Acelda(1,i))*ajuste;
    end
end
Acelda