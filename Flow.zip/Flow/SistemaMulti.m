%Sistema de ecuaciones para multicelda
B=zeros(nq); %matriz de coeficientes
Bnh=zeros(nq,1); %vector solucion
%--- Ecuaciones de giro ---
k=1;
for i=nq-(ce-2):nq 
    k=k+1;
    B(i,:)=Bfi(1,:)-Bfi(k,:);
end
%--- ecuaciones de chapas  externas---
for i=1:n-1
    B(i,i)=-1;
    B(i,i+1)=1;
    Bnh(i,1)=dSa(1,i);
end
npos=n;
for i=1:ce-1
    li=div1(1,i);
    lf=div2(1,i);
    npos=npos+1;
    B(li,npos)=1;
    npos=npos+ni(i);
    B(lf,npos)=-1;
end
%--- ecuaciones de chapas internas ---
k=n-1;
k1=n;
k2=n-1;
for i=1:ce-1
    k=k+1;
    if ni(1,i)~=0
        for j=1:ni(1,i)
         k=k+1;
         k1=k1+1;
         k2=k2+1;
         B(k2,k)=-1;
         B(k2,k+1)=1;
         Bnh(k2,1)=dSa(1,k1);
        end
    end
end
%--- ecuacion de momento ---
Bnh(nt,1)=-P(1,1)*(P(1,2)-Cg(2,2))+P(1,3)*(P(1,4)-Cg(2,1));
for i=1:n
    B(nt,i)=2*Ab(1,i);
end
k=n;
for i=1:ce-1
    ki=div1(1,i);
    kf=div2(1,i);
    if ni(1,i)~=0
       for j=1:ni(1,i)+1
           k=k+1;
           lx=abs(xce(i,j)-xce(i,j+1)); %proyeeccion horizontal de la chapa
           lx2=(xce(i,j)+xce(i,j+1))/2; %punto medio en x de la chapa
           ly=abs(yce(i,j)-yce(i,j+1)); %proyeccion vertical de la chapa
           ly2=(yce(i,j)+yce(i,j+1))/2; %punto medio en y de la chapa
           if (xce(i,1)>xce(i,ni(1,i)+2))||(yce(i,1)<yce(i,ni(1,i)+2))       %condiciones para el momento sea antihorario
               m=-ly2*lx-lx2*ly;
           else
               m=ly2*lx+lx2*ly;
           end
           B(nt,k)=m;
       end
    else
        k=k+1;
        lx=abs(xce(i,1)-xce(i,2)); %proyeeccion horizontal de la chapa
        lx2=(xce(i,1)+xce(i,2))/2; %punto medio en x de la chapa
        ly=abs(yce(i,1)-yce(i,2)); %proyeccion vertical de la chapa
        ly2=(yce(i,1)+yce(i,2))/2; %punto medio en y de la chapa
        if (xce(i,1)>xce(i,ni(1,i)+2))||(yce(i,1)<yce(i,ni(1,i)+2))%condiciones para el momento sea antihorario
           m=-ly2*lx-lx2*ly;
        else
           m=ly2*lx+lx2*ly;
        end
           B(nt,k)=m;
    end
end