% Configuracion de visualizaciones (y otros en el futuro)

disp(' ')
disp(' ')
disp('--------------------')
disp('    Preferencias')
disp('--------------------')
disp([' 1-Resultados de tensiones: ' Pref.Tensiones])
disp([' 2-Carga critica de pandeo: ' Pref.CargaPandeo])
disp(' ')
disp(' 0-Volver')
disp(' ')
choosePref=input('Elija un opci�n: ');
disp(' ')

switch choosePref
    case 1
        disp(' En las tablas de resultados de tensiones ver:')
        disp('  1 - Absoluto: valor de tension de cada cordon/chapa')
        disp('  2 - Diferencia: diferencia entre tension limite y tension obtenida')
        disp('  3 - Relacion: cociente entre tension obtenida y tension limite')
        disp(' ')
        choosePref2=input('Elija un opci�n: ');
        switch choosePref2
            case 1
                Pref.Tensiones = 'Absoluto';
            case 2
                Pref.Tensiones = 'Diferencia';
            case 3
                Pref.Tensiones = 'Relacion';
        end
        
        Preferencias
        
    case 2
        disp(' Usar como carga critica de pandeo:')
        disp('  1 - Local: carga critica de pandeo local (metodo de secciones planas)')
        disp('  2 - Columna: carga de colpaso de columna (Euler/Johnson)')
        disp(' ')
        choosePref2=input('Elija un opci�n: ');
        switch choosePref2
            case 1
                Pref.CargaPandeo = 'Local';
                PandeoL
                
            case 2
                Pref.CargaPandeo = 'Columna';
                disp(' ')
                disp(' Por simplicidad en la visualizacion de resultados, no se calcula')
                disp('la carga critica para cada estacion, sino que se calcula un unico')
                disp('valor para cada cordon segun una longitud a eleccion.')
                disp(' 1 - Maxima longitud de estacion')
                disp(' 2 - Minima longitud de estacion')
                disp(' 3 - Ingresar longitud de referencia')
                disp(' ')
                choosePref3=input('Elija un opci�n: ');
                switch choosePref3
                    case 1 
                        Pref.LongRef = 'Maxima';
                    case 2 
                        Pref.LongRef = 'Minima';
                    case 3 
                        Pref.LongRef = 'Referencia';
                end
                PandeoC
        end
        
        Preferencias
        
    case 0
        PostCalculos
        
    otherwise
        Preferencias
end
