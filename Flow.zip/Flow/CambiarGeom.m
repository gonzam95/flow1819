switch changeGeom
    case 1
        nse=input('Cantidad de estaciones: ');

    case 2
        n=input('Cantidad de cordones: ');

    case 3
        disp(' ')
        disp([' 1-Cantidad de celdas: ' num2str(ce)])
        disp(' 2-Ubicacion de divisiones')
        disp(' 0-Volver')
        disp(' ')
        auxGeom=input('Elija una opci�n: ');
        switch auxGeom
            case 1
                ce=input('Cantidad de celdas: ');
                
            case 2
                disp(' Larguero donde comienza la division: ')
                disp(div1)
                disp(' Larguero donde termina la division: ')
                disp(div2)
                changeni=input('Cambiar valor de divisi�n n�: ','s');
                compare=strcmp(changeni,'all');
                if compare==1 %si ingreso all
                    if ce>1
                        div1=zeros(1,ce-1);
                        div2=zeros(1,ce-1);
                        for i=1:ce-1 % loop para cantidad de divisiones
                            disp(['Division ' num2str(i)])
                             div1(1,i)=input('N� de cordon donde comienza: ');
                             div2(1,i)=input('N� de cordon donde termina: ');
                        end
                    end
                elseif compare==0; %si ingreso un numero
                    changeni=str2double(changeni);
                    if changeni>0
                        div1(1,changeni)=input('N� de cordon donde comienza: ');
                        div2(1,changeni)=input('N� de cordon donde termina: ');
                    end
                end %fin if compare
                clear changeni tf
            otherwise
                MenuGeom
        end
%% Cantidad de largueros en divisiones
    case 4
        disp(' ')
        disp('Valores ingresados: ')
        disp(ni) % cantidad de largueros definidos en cada division de celda
        disp(' ')
        changeni=input('Cambiar valor de divisi�n n�: ','s');
        compare=strcmp(changeni,'all');
        if compare==1 %si ingreso all
            if ce>1
                ni=zeros(1,ce-1);
                for i=1:ce-1 % loop para cantidad de divisiones
                    disp(['Division ' num2str(i)])
                    ni(1,i)=input('Cantidad de cordones intermedios: ');
                end
            end
        elseif compare==0; %si ingreso un numero
            changeni=str2double(changeni);
            if changeni>0
                ni(1,changeni)=input('Cantidad de cordones en la divisi�n: ');
            end
        end %fin if compare
        clear changeni tf
%% Longitud de secciones
    case 5
        disp(' ')
        disp('Longitud de secciones')
        disp(long) %valores ingresados
        disp(' ')
        disp('Posiciones en z de estaciones')
        disp(z)
        changelong=input('Cambiar longitud de seccion n�: ');
        compare=strcmp(changelong,'all');
        if compare==1 %si ingreso all
            long=zeros(1,nse-1);
            z=zeros(1,nse);
            for i=1:nse-1 %loop por cantidad de secciones
                disp(['Secci�n ' num2str(i)])
                long(1,i)=input('Longitud de la secci�n: ');
                z(1,i+1)=sum(long);
                save('Flow');
            end
        elseif compare==0 %si ingreso un numero
            changelong=str2double(changelong);
            if changelong>0
                long(1,changelong)=input('Longitud de la secci�n: ');
            end
            long2=zeros(1,nse-1);
            z=zeros(1,nse);
            for i=1:nse-1
                long2(1,i)=long(1,i);
                z(1,i+1)=sum(long2);
            end
            clear changelong long2 tf
        end
%% Valores en X de largueros
    case 6
        disp(' ')
        disp('Valores ingresados: ')
        disp(Xs)
        disp(' ')
        changex=input('Cambiar valores de estaci�n n�: ','s');
        compare=strcmp(changex,'all');
        if compare==1
            Xs=zeros(nse,n+sum(ni));
            for k=1:nse %loop por cantidad de estaciones
                disp(['Estacion ' num2str(k-1)])
                for i=1:n+sum(ni) %loop por cant total de largueros
                    disp([' Cordon ' num2str(i)]);
                    Xs(k,i)=input('  Valor de X: ');
                    save('Flow');
                end
            end
        elseif compare==0; 
            changex=str2double(changex);
          if changex>0
            disp(Xs(changex,:))
            disp(' ')
            changex2=input('Cambiar valor de cordon n�: ','s');
            compare=strcmp(changex2,'all');
            if compare==1 %cambiar todas las areas de la estacion
                Xts=zeros(1,n+sum(ni));
                for i=1:n+sum(ni) %loop por cantidad de cordones
                    disp([' Cordon ' num2str(i)])
                    Xts(1,i)=input('  Valor de X: ');
                    save('Flow');
                end
                Xs(changex,:)=Xts(1,:);
            elseif compare==0
                changex2=str2double(changex2);
                Xs(changex,changex2)=input(' Valor de X: ');
            end
          end
        end
        clear changex changex2 Xts

%% Valores en Y de largueros
    case 7 
        disp(' ')
        disp('Valores ingresados: ')
        disp(Ys)
        disp(' ')
        changey=input('Cambiar valores de estaci�n n�: ','s');
        compare=strcmp(changey,'all');
        if compare==1
            Ys=zeros(nse,n+sum(ni));
            for k=1:nse %loop por cantidad de estaciones
                disp(['Estacion ' num2str(k-1)])
                for i=1:n+sum(ni) %loop por cantidad de cordones
                    disp([' Cordon ' num2str(i)]);
                    Ys(k,i)=input('  Valor de Y: ');
                    save('Flow');
                end
            end
        elseif compare==0; 
            changey=str2double(changey);
          if changey>0
            disp(Ys(changey,:))
            changey2=input('Cambiar valor de cordon n�: ','s');
            compare=strcmp(changey2,'all');
            if compare==1 %cambiar todas las areas de la estacion
                Yts=zeros(1,n+sum(ni));
                for i=1:n+sum(ni) %loop por cantidad de cordones
                    disp([' Cordon ' num2str(i)])
                    Yts(1,i)=input('  Valor de Y: ');
                    save('Flow');
                end
                Ys(changey,:)=Yts(1,:);
            elseif compare==0
                changey2=str2double(changey2);
                Ys(changey,changey2)=input(' Valor de Y: ');
            end
          end
        end
        clear changey changey2 Yts
%% Cambiar areas de largueros
    case 8 
        disp(' ')
        disp('Valores ingresados: ')
        disp(As)
        disp(' ')
        changea=input('Cambiar valores de Seccion n�: ','s');
        compare=strcmp(changea,'all');
        if compare==1
            As=zeros(nse-1,n+sum(ni));
            for k=1:nse-1 %loop por cantidad de secciones
                disp(['Estacion ' num2str(k-1)])
                for i=1:n+sum(ni) %loop por cantidad de cordones
                    disp([' Cordon ' num2str(i)]);
                    As(k,i)=input('  Valor de Area: ');
                    save('Flow');
                end
            end
        elseif compare==0; 
            changea=str2double(changea);
          if changea>0
            disp(As(changea,:))
            changea2=input('Cambiar valor de cordon n�: ','s');
            compare=strcmp(changea2,'all');
            if compare==1 %cambiar todas las areas de la estacion
                Ats=zeros(1,n+sum(ni));
                for i=1:n+sum(ni)
                    disp([' Cordon ' num2str(i)])
                    Ats(1,i)=input('  Valor de A: ');
                    save('Flow');
                end
                As(changea,:)=Ats(1,:);

            elseif compare==0
                changea2=str2double(changea2);
                As(changea,changea2)=input(' Valor de A: ');
            end
          end
        end
        clear changea changea2 Ats
%% Cambiar espesores de chapas
    case 9
        disp(' ')
        disp('Valores ingresados: ')
        disp(Ts)
        disp(' ')
        nq=n+ce-1+sum(ni);
        changea=input('Cambiar valores de Seccion n�: ','s');
        compare=strcmp(changea,'all');
        if compare==1
            if nse==1
                nesp=1;
            else
                nesp=nse-1;
            end
            Ts=zeros(nse,nq);
            for k=1:nesp %loop por cantidad de secciones
                disp(['Seccion ' num2str(k-1)])
                for i=1:nq %loop por cantidad total de chapas
                    disp([' Chapa ' num2str(i)]);
                    Ts(k,i)=input('  Valor de espesor: ');
                    save('Flow');
                end
            end

        elseif compare==0; 
            changea=str2double(changea);
          if changea>0
            disp(Ts(changea,:))
            if Ts==0
                clear Ts
            end
            disp(' ')
            changea2=input('Cambiar valor de chapa n�: ','s');
            compare=strcmp(changea2,'all');
            if compare==1 %cambiar todos los valores
                Tts=zeros(1,nq);
                for i=1:nq %loop por cantidad de chapas
                    disp([' Chapa ' num2str(i)])
                    Tts(1,i)=input('  Valor de t: ');
                    save('Flow');
                end
                Ts(changea,:)=Tts(1,:);
            elseif compare==0
                changea2=str2double(changea2);
                Ts(changea,changea2)=input(' Valor de t: ');
            end
          end
        end
        clear changea changea2 Tts tf
end
save('Flow');
clear nonzero
NonZero;
MenuGeom; %despues del case correspondiente regresa al menu de cambiar geometria