%Definir secciones de largueros
NonZero; % quita las filas con areas nulas
%Accedo desde script Material.m
nt=n+sum(ni);
if MSecciones==0
    Seccion=zeros(nt,1); Seccion=char(Seccion); % vector string que contiene el tipo de seccion
    Dimensiones=zeros(nt,3); %longitud de cada parte de la seccion
    Espesores=zeros(nt,3); %espesor de cada parte de la seccion
    Areas=zeros(nt,1); %Area dtransversal de la seccion
    Jz=zeros(nt,1); % momento de inercia de la seccion
    Sigmacr=zeros(nt,1); %sigma critico de pandeo 
    PCritica=zeros(nt,1); %carga critica de pandeo ingresada
    
    for k=1:nt
        Seccion(k)='-';
    end
else
    Areas=Lprop(:,1); %Lprop se calcula en PandeoL;
    Jz=Lprop(:,2);
end
clear T
T.Larguero=nnc;
cont=0;
for i=1:length(nnc1)
%decirle a los vectores que formaran la tabla que eliminen la fila
%correspondiente a largueros cuya area=0
    if nnc1(i,1)~=0
       cont=cont+1;
       T.Sec(cont,1)=Seccion(i,1);
       T.Dim(cont,:)=Dimensiones(i,:);
       T.Esp(cont,:)=Espesores(i,:);
       T.Area(cont,1)=Areas(i,1);
       T.Jz(cont,1)=Jz(i,1);
       T.Scr(cont,1)=Sigmacr(i,1);
        
   end

end
disp(' ')
disp('----------------------') 
disp('Secciones de largueros')
disp('----------------------')
disp(' ')
if(MSecciones~=0)
    T=table(T.Larguero,T.Sec,T.Dim,T.Esp,T.Area,T.Jz,T.Scr,'VariableNames',{'Larguero','Seccion','Dimensiones','Espesores','Areas','Jz','Sigmacr'});
    disp(T)
end
disp(' ')
disp(' 1-Definir secciones')
disp(' 2-Guardar secciones')
disp(' 3-Cargar secciones')
disp(' 4-Corregir areas')
disp(' 0-Atras')
disp(' ')
ch=input('Elija una opci�n: ');
disp(' ')

switch ch
    case 0
        clear ch
        Material;
        
    case 1
        clear ch
        disp(' ')
        disp('----------------------') 
        disp('Secciones de largueros')
        disp('----------------------')
        disp(' ')
        disp(' 1-Perfil Z')
        disp(' 2-Perfil L')
        disp(' 3-Perfil T')
        disp(' ')
        ch=input('Elija un tipo de perfil: ');
        MSecciones=1;
        disp(' ')
        
        switch ch
            case 1
                disp(' ')
                disp('    -1-')
                disp('       |')
                disp('       2')
                disp('       |')
                disp('        -3-')
                disp(' ')
                l1=input('Ingrese longitud de la chapa 1: ');
                t1=input('Ingrese espesor de la chapa 1: ');
                l2=input('Ingrese longitud de la chapa 2: ');
                t2=input('Ingrese espesor de la chapa 2: ');
                l3=input('Ingrese longitud de la chapa 3: ');
                t3=input('Ingrese espesor de la chapa 3: ');
                disp(' ')
                disp('Si no conoce la carga critica de pandeo ingrese cero')
                tPcr = input('Carga critica de pandeo: ');
                %% 
                disp(' ')
                disp('Ingrese los numeros de largueros a los que quiere asignar esta secci�n,')
                lar=input('dejando un espacio entre cada numero: ','s');
                lar=(str2num(lar))';
                for k=1:length(lar)
                    k1=lar(k);
                    if (k1<=n)
                        if nnc1(k1,1)~=0
                            Seccion(k1)='Z';
                            Dimensiones(k1,1)=l1; Dimensiones(k1,2)=l2; Dimensiones(k1,3)=l3;
                            Espesores(k1,1)=t1; Espesores(k1,2)=t2; Espesores(k1,3)=t3;
                            PCritica(k1) = tPcr;
                        end
                    end
                end
                clear ch l1 l2 l3 t1 t2 t3 lar k k1
                
            case 2
                disp(' ')
                disp(' --1--')
                disp('      |')
                disp('      2')
                disp('      |')
                disp(' ')
                l1=input('Ingrese longitud de la chapa 1: ');
                t1=input('Ingrese espesor de la chapa 1: ');
                l2=input('Ingrese longitud de la chapa 2: ');
                t2=input('Ingrese espesor de la chapa 2: ');
                disp(' ')
                disp('Si no conoce la carga critica de pandeo ingrese cero')
                tPcr = input('Carga critica de pandeo: ');
                %%
                disp(' ')
                disp('Ingrese los numeros de largueros a los que quiere asignar esta secci�n,')
                lar=input('dejando un espacio entre cada numero: ','s');
                lar=(str2num(lar))';
                for k=1:length(lar)
                    k1=lar(k);
                    if k1<=n
                        Seccion(k1)='L';
                        Dimensiones(k1,1)=l1; Dimensiones(k1,2)=l2;
                        Espesores(k1,1)=t1; Espesores(k1,2)=t2;
                        PCritica(k1) = tPcr;
                    end
                end
                clear ch l1 l2 t1 t2 lar k k1
                
            case 3
                
                disp(' ')
                disp(' --1-- --2--')
                disp('      |')
                disp('      3')
                disp('      |')
                disp(' ')
                
                l1=input('Ingrese longitud de la chapa 1: ');
                t1=input('Ingrese espesor de la chapa 1: ');
                l2=input('Ingrese longitud de la chapa 2: ');
                t2=input('Ingrese espesor de la chapa 2: ');
                l3=input('Ingrese longitud de la chapa 3: ');
                t3=input('Ingrese espesor de la chapa 3: ');
                disp(' ')
                disp('Si no conoce la carga critica de pandeo ingrese cero')
                tPcr = input('Carga critica de pandeo: ');
                %% 
                disp(' ')
                disp('Ingrese los numeros de largueros a los que quiere asignar esta secci�n,')
                lar=input('dejando un espacio entre cada numero: ','s');
                lar=(str2num(lar))';
                for k=1:length(lar)
                    k1=lar(k);
                    if (k1<=n)
                        if nnc1(k1,1)~=0
                            Seccion(k1)='T';
                            Dimensiones(k1,1)=l1; Dimensiones(k1,2)=l2; Dimensiones(k1,3)=l3;
                            Espesores(k1,1)=t1; Espesores(k1,2)=t2; Espesores(k1,3)=t3;
                            PCritica(k1) = tPcr;
                        end
                    end
                end
                clear ch l1 l2 l3 t1 t2 t3 lar k k1
                
        end
        PandeoL;
        disp(' ')
disp('******************************************************************')
disp(' NOTA: En los casos en que la PCritica no fue definida,')
disp('se define la carga critica de pandeo como la carga que genera')
disp('pandeo local, calculada segun el metodo de secciones planas')
disp(' Tras calcular el cajon en la opcion ''Preferencias'' puede elegir')
disp('trabajar con la carga de colapso de columna')
disp('******************************************************************')

        save('Flow')
        Secciones;
        
    case 2
        gsec=input('Escriba el numero de larguero que contiene la seccion que desea guardar: ');
        gs.sec=Seccion(gsec);
        gs.dim=Dimensiones(gsec,:);
        gs.esp=Espesores(gsec,:);
        gname=input('Ingrese nombre de la secci�n: ','s');
        dir=pwd;
        cd(strcat(pwd,'\Secciones'))
        save(gname,'gs');
        cd(dir);
        disp('--- Datos guardados ---')
        Secciones;
        
    case 3
        dir=pwd;
        cd(strcat(pwd,'\Secciones'))
        disp(' ')
        disp('Archivos disponibles: ')
        disp(' ')
        ls
        disp(' ')
        gsec=input('Ingrese el nombre de la secci�n: ','s');
        try 
            load(gsec);
            disp(' ')
            disp('--- Datos cargados ---')
            gload=1;
        catch ME
            gload=0;
            disp(' ')
            disp('No se pudo cargar el archivo solicitado.')
            disp(ME.message)
        end
        cd(dir)
        
        disp('Ingrese los numeros de largueros a los que quiere asignar esta secci�n,')
        lar=input('dejando un espacio entre cada numero: ','s');
        lar=(str2num(lar))';
        
        if(gload==1)
        for k=1:length(lar)
            k1=lar(k);
            if k1<=n
                Seccion(k1)=gs.sec;
                Dimensiones(k1,:)=gs.dim;
                Espesores(k1,:)=gs.esp;
             end
        end
        end
        MSecciones=1;
        clear gload gs lar gsec
        PandeoL;
        disp(' ')
disp('******************************************************************')
disp(' NOTA: En los casos en que la PCritica no fue definida,')
disp('se define la carga critica de pandeo como la carga que genera')
disp('pandeo local, calculada segun el metodo de secciones planas')
disp(' Tras calcular el cajon en la opcion ''Preferencias'' puede elegir')
disp('trabajar con la carga de colapso de columna')
disp('******************************************************************')

        save('Flow')
        Secciones;

    case 4
        Anterior=As(1,:)';
        Nuevo=Areas;
        T=table(Anterior,Nuevo);
        disp(T)
        disp('Esta acci�n asignar� la misma secci�n a cada larguero en todas las estaciones')
        change=input('Confirma que desea cambiar los valores de Areas [S/N]: ','s');
        if(strcmp(change,'S')==1)
            for j=1:nse
                As(j,:)=Areas;
            end
        end
        Secciones;
        
end




