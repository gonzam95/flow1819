%% Menu principal
disp(' ')
disp('--------------------')
disp('        Flow')
disp('--------------------')
disp('  1-Ingresar geometria')
if chooseGeom~=0
    disp('  2-Cambiar geometria')
end
disp('  3-Ingresar estado de carga')
if chooseCarga~=0
    disp('  4-Cambiar estado de carga')
end
disp(' ')
disp('  5-Datos adicionales')
disp('  6-Importar datos')
disp(' ')
disp('  7-Guardar datos')
disp('  8-Cargar datos')
disp(' ')
if (chooseGeom~=0)&&(chooseCarga~=0)
    disp('  9-Calcular')
end
if chooseGeom~=0
    disp(' 10-Graficar geometria')
    disp(' ')
end
disp(' 90-Reiniciar')
disp('  0-Salir')
disp(' ')
chooseFlow=input(' Elija una opci�n: ');

%% Opcion elegida
switch chooseFlow
    case 1 %ingresar geom
        chooseGeom=1;
        MenuGeom;
    
    case 2 %cambiar geom
        if(chooseGeom==0), Inicio;
        else
            chooseGeom = 2;
            MenuGeom;
        end
    
    case 3 %ingresar carga
        chooseCarga=1;
        MenuCarga;
        
    case 4 %cambiar carga
        if(chooseCarga==0), Inicio;
        else
            chooseCarga = 2;
            MenuCarga;
        end
        
    case 5 %ingresar material y geometria de largueros
        Material;

    case 6 %importar datos
        chooseCarga=1;
        chooseGeom=1;
        Importar;
    case 7 %guardar datos
        SaveLoad;

    case 8 %cargar datos
        SaveLoad;

    case 9 %calcular
        if (chooseGeom~=0)&&(chooseCarga~=0)
            Calculado=1;
            save('Flow')
            Calculos;
        else
            Inicio;
        end
        
    case 10
        GrafO=0;
        Grafico;
        Inicio;
        
    case 90
        clear
        Flow
        
    case 0 %cerrar programa
        disp(' ')
        disp('--- --- --- ---')
        disp(' ')

    otherwise 
        Inicio;
end %fin de Switch chooseFlow