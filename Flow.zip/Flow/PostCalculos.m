%% variables de preferencias 
% por si no se cargan con los datos

if not(exist('Pref','var'))
    Pref = load('PrefDef');
end
if strcmp(Pref.CargaPandeo,'Columna')&&MSecciones==1
    PandeoC
end

%%
disp(' ')
disp(' ')
disp('--------------------')
disp('        Flow')
disp('--------------------')
disp(' 1-Resultados')
disp(' 2-Optimizar')
disp(' 3-Cambiar datos')
disp(' 4-Recalcular')
%disp(' 5-Calculos realizados') %No vale la pena
disp(' 5-Guardar estado')
disp(' ')
disp(' 9-Volver al menu principal')
disp('10-Preferencias')
disp(' 0-Salir')
disp(' ')
chooseFlow=input('Elija un opci�n: ');
    
switch chooseFlow
    case 0
        disp(' ')
        disp('--- --- --- ---')
        disp(' ')

    case 1
        Resultados;

    case 2
        Optimizar;
        %La idea de esta seecion seria poder elegir una parametro y
        %poder modificarlo viendo rapidamente las consecuencias.
        
    case 3
        disp(' ')
        disp('--------------------')
        disp('        Flow')
        disp('--------------------')
        disp(' 1-Cambiar geometria')
        disp(' 2-Cambiar carga')
        disp(' 3-Cambiar datos adicionales')
        disp(' 0-Atras')
        disp(' ')
        chooseChange=input('Elija una opci�n: ');
        switch chooseChange
            case 0 
                PostCalculos;
            case 1
                chooseGeom=2;
                MenuGeom;
            case 2
                chooseCarga=2;
                MenuCarga;
            case 3
                Material;
        end
        
    case 4
        Optim = 0;
        Calculos;
%     case 5
%         %TODO: Procedimientos; mostrar los calculos realizados

    case 5
        SaveLoad;
        
    case 9
        Flow;
        
    case 10
        Preferencias
end
        