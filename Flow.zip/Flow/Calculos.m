tstart = tic;

nq=n+ce-1+sum(ni); %num de chapas
ecs=nq-(ce); %num de ecuaciones de chapas
nt=n+sum(ni); %num de largueros
if nse==1
    numU=1; %cantidad de secciones a calcular
else 
    numU=nse-1;
end
allq=zeros(2,nq,numU); % inicializo vectores donde guardar resultados
allH=zeros(2,nt,numU);
allV=zeros(2,nt,numU);
allS=zeros(2,nt,numU);
allR=zeros(2,nt,numU);
alldS=zeros(1,nt,numU);
allCg=zeros(numU,2);
allJx=zeros(numU,1);
allJy=zeros(numU,1);
allJxy=zeros(numU,1);
P=zeros(1,4);
Mfpx=0;
Mfpy=0;
Mtce=0;
    
for u=1:numU %loop sobre las secciones
    %% Definicion de la seccion
    %longitud de la seccion
    lse=long(1,u);
    %momento flector acumulado
    if u~=1
%         for j=1:u
%             Mfpx=Mfpx+Pce(j,3)*long(1,u-1);%z(1,u); % momento flector acumulado hasta la 
%             Mfpy=Mfpy+Pce(j,1)*long(1,u-1);%*z(1,u); % 1� estacion de la seccion
        Mfpx=Mfpx+P(1,3)*long(1,u-1);
        Mfpy=Mfpy+P(1,1)*long(1,u-1);
        % multiplico por long de seccion anterior porque Mfpx ya contiene el momento resultante
        % de trasladar todas las cargas hasta la seccion anterior. Solo
        % falta sumar el momento de trasladar todas las cargas desde la
        % seccion anterior
%         end
    elseif u==1
        P(1,2)=Pce(u,2);
        P(1,4)=Pce(u,4);
        Mfpx = Mfx;
        Mfpy = Mfy;
        
    end
    %% cargas en la 1� estacion de la seccion
    if P(1,1)+Pce(u,1)~=0 % si la carga total no es nula
        P(1,2)=(P(1,1)*P(1,2)+Pce(u,1)*Pce(u,2))/(P(1,1)+Pce(u,1)); % saco ubicacion de la carga por promedio 
    end
    if P(1,3)+Pce(u,3)~=0
        P(1,4)=(P(1,3)*P(1,4)+Pce(u,3)*Pce(u,4))/(P(1,3)+Pce(u,3));
    end
    P(1,1)=P(1,1)+Pce(u,1); % cargas acumuladas
    P(1,3)=P(1,3)+Pce(u,3);
    %area de largueros en la seccion
    A(1,:)=As(u,:); 
    %posicion de largueros
    X(1,:)=Xs(u,:); % 1� estacion
    X(2,:)=Xs(u+1,:); % 2� estacion
    Y(1,:)=Ys(u,:);
    Y(2,:)=Ys(u+1,:);
    %Mtce=Mtce+Mt(u,1); %momento torsor en la 1� estacion
    
    %  Si solo se ingresa Mt y Px=Py=0, se deben plantear ecuaciones distintas a las propuestas.
    
    %% Calculo
    Resolucion;
    
    %% Mostrar matrices de calculo
    if exist('Matrices','var')
        disp(' ')
        disp([' Seccion ' num2str(u)])
        disp(' ')
        disp([' Px = ' num2str(P(1)) ' - DistY = ' num2str(P(2))])
        disp([' Py = ' num2str(P(3)) ' - DistY = ' num2str(P(4))])
        disp(' ')
        disp(' Matriz A =')
        disp(B)
        disp(' ')
        disp(' Matriz B')
        disp(Bnh)
        disp(' ')
        disp(' Relaciones de ahusamiento')
        disp(l)
    end
    
    %% Guardar resultados
    %acumulo resultados por seccion
    allq(:,:,u)=q; % flujo de corte en ambas estaciones
    allS(:,:,u)=S; % esfuerzos sobre los largueros
    alldS(:,:,u)=dSa;
    allCg(u,:)=Cg(1,:); % ubicacion del cg de 1� estacion
    allCg(u+1,:)=Cg(2,:); % ubicacion del cg de 2� estacion
    allJx(u,1)=Jx(1,1);
    allJx(u+1,1)=Jx(2,1);
    allJy(u,1)=Jy(1,1);
    allJy(u+1,1)=Jy(2,1);
    allJxy(u,1)=Jxy(1,1);
    allJxy(u+1,1)=Jxy(2,1);
    allH(:,:,u)=dH;% esfuerzos sobre le larguero en x
    allV(:,:,u)=dV; % esfuerzos sobre el larguero en y 
    R=(S.^2+dH.^2+dV.^2).^0.5; %esfuerzos totales sobre el larguero
    allR(:,:,u)=R;    
end

tend = toc(tstart);
disp(['Tiempo de calculo: ' num2str(tend) ' segundos'])

switch Optim
    case 0
        PostCalculos;
    case 1
        Optimizacion;
end