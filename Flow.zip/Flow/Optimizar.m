%% Herramienta para cambiar valores rapidamente y recalcular


disp(' ')
disp('--------------------')
disp('      Optimizar')
disp('--------------------')
disp([' 1-Afectar: ' Optim1])
disp([' 2-Ver resultados de: ' Optim2])
disp([' 3-Resultados de tensiones: ' Pref.TensOpt])
disp([' 4-Carga critica de pandeo: ' Pref.TensPcr])
%disp([' 3-Aplicar areas equivalentes: ' Idealiz])
disp(' ')
disp(' 5-Cambiar areas')
disp(' 6-Cambiar espesores')
if MSecciones==1
    disp(' 7-Cambiar secciones')
end
disp(' 0-Atras')
disp(' ')
chooseOpt=input('Elija un opci�n: ');
disp(' ')

switch chooseOpt
    case 1
        disp('1-Toda la viga    2-Solo una estaci�n')
        disp(' ')
        Opt1=input('Elija una opci�n: ');
        switch Opt1
            case 1
                Optim1='Toda la viga';
                nOptim=0;
            case 2
                disp(' ')
                nOptim=input('Numero de estacion: ');
                while (nOptim<1)||(nOptim>nse)
                    disp(['El numero de estacion debe ser mayor a cero y menor a ' num2str(nse)])
                    nOptim=input('Numero de estacion: ');
                end
                Optim1=strcat('Estacion ',num2str(nOptim));
                disp(' ')
        end
        Optimizar;
    
    case 2
    
        disp('1-Toda la viga    2-Solo una estaci�n')
        disp(' ')
        Opt1=input('Elija una opci�n: ');
        switch Opt1
            case 1
                Optim2='Toda la viga';
                nOptim2=0;
            case 2
                disp(' ')
                nOptim2=input('Numero de estacion: ');
                while (nOptim2<1)||(nOptim>nse)
                    disp(['El numero de estacion debe ser mayor a cero y menor a ' num2str(nse)])
                    nOptim2=input('Numero de estacion: ');
                end
                Optim2=strcat('Estacion ',num2str(nOptim2));
                disp(' ')
        end
        Optimizar;

    case 3
        disp(' En la columna de tensiones ver:')
        disp('  1 - Absoluto: valor de tension de cada cordon/chapa')
        disp('  2 - Diferencia: diferencia entre tension limite y tension obtenida')
        disp('  3 - Relacion: cociente entre tension obtenida y tension limite')
        disp(' ')
        choosePref2=input('Elija un opci�n: ');
        switch choosePref2
            case 1
                Pref.TensOpt = 'Absoluto';
            case 2
                Pref.TensOpt = 'Diferencia';
            case 3
                Pref.TensOpt = 'Relacion';
        end
        
        Optimizar
%     case 3
%         Idealiz = input('Desea utilizar areas equivalentes para el calculo [S/N]: ','s');
%         
    case 4
        disp(' Calcular la carga critica de pandeo:')
        disp(' Local')
        disp(' Columna')
        disp(' ')
        choosePref2=input('Elija un opci�n: ');
        switch choosePref2
            case 1
                Pref.TensPcr = 'Local';
            case 2
                Pref.TensPcr = 'Columna';
        end
                
    case 5
        auxCambiar = 1; % cambiar areas
        Optimizacion
        
    case 6
        auxCambiar = 2; % cambiar espesores
        Optimizacion
        
    case 7
        auxCambiar = 3; % cambiar secciones
        Optimizacion
   
    case 0
        PostCalculos;
    
end


