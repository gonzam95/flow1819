% redefinir areas usando areas equivalentes


Areal=As; %guardo areas ingresadas
Aeq=zeros(size(As));
    
nt=n+sum(ni); %num de largueros

for i=1:nse %cada seccion
for j=1:nt-1 %cada chapa
    if As(1,j)==0
        Aeq(i,j)=0;
    else
        if As(1,j+1)==0
            cont = j;
            b1=0;
            while As(1,cont+1)==0
                b1=b1+((Xc0(i,cont)-Xc0(i,cont+1))^2+(Yc0(i,cont)-Yc0(i,cont+1))^2)^0.5;
                cont=cont+1;
            end
            tm=0;
            for m=i:cont
                tm=tm+Ts(i,m);
            end
            tm=tm/(cont-i);
            if(Yc0(i,j)>=0)&&(Yc0(i,cont+1)>=0) 
                s1=Mfpx
%                 if(Yc0(i,j)>Yc0(i,cont+1)) % esto esta mal porque no considera los esfuerzos horizontales
%                     y1=Yc0(i,j);
%                     y2=Yc0(i,cont+1);
%                 else
%                     y1=Yc0(i,cont+1);
%                     y2=Yc0(i,j);
%                 end
            end
        else
            cont=i+1;
            b1=((Xc0(i,j)-Xc0(i,j+1))^2+(Yc0(i,j)-Yc0(i,j+1))^2)^0.5;
            tm=Ts(i,j);
            if(Yc0(i,j)>=0)&&(Yc0(i,j+1)>=0) 
%                 if(Yc0(i,j)>Yc0(i,j+1))
%                     y1=Yc0(i,j);
%                     y2=Yc0(i,j+1);
%                 else
%                     y1=Yc0(i,j+1);
%                     y2=Yc0(i,j);
%                 end
            end
        end
        if(Yc0(i,j)>=0)&&(Yc0(i,j+1)>=0)
            if(y1>0)||(y2>0)
                Aeq(i,j)=(b1*tm/6)*(2+y1/y2);
                Aeq(i,cont)=(b1*tm/6)*(2+y2/y1);
            elseif y2==0
                Aeq(i,j)=b1*tm/6;
            end
        end
        
        if (Yc0(i,j)<0)||(i==1)
            Aeq(i,j)=2*20*tm^2;
        end
        if (Yc0(i,j+1)<0)||(As(i,j+1)~=0)
            Aeq(i,j+1)=2*20*tm^2;
        end
    end
end
end

if nse==1
    Aeq(2,:)=Aeq(1,:);
end

As = Areal+Aeq;

