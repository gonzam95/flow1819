
switch chooseGeom
    case 1 %definir nuevos valores
%% Nueva geometria
    disp(' ')
    disp('-------------------') 
    disp('  Nueva Geometria')
    disp('-------------------')
    disp(' ')
    nse=input('Cantidad de estaciones: '); 
    n=input('Cantidad de cordones: ');
    ce=input('Cantidad de celdas: ');
    if nse==1 
        nsec=2; %auxiliar para cuando tenga una sola estacion
    else
        nsec=nse;
    end
    long=zeros(1,nse-1); % longitud de cada seccion
    z=zeros(1,nsec); % posicion en z de las estaciones
    As=zeros(nse-1,n); % areas de largueros (tiene una componente menos porque considero igual area en cada seccion)
    Xs=zeros(nse,n); % posicion en x de largueros
    Ys=zeros(nse,n); % posicion en y de largueros
    xii=[]; %vectores inicialmente vacios par luego ingresar valores de x, y y areas
    yii=[]; %de los largueros en divisiones de celdas (si los hubiera)
    aii=[];
    if ce>1 %si ay mas de una celda
        div1=zeros(1,ce-1); % num de larguero donde inicia la division
        div2=zeros(1,ce-1); % num de larguero donde termina la division
        ni=zeros(1,ce-1); % cantidad de largueros en la division
    else
        div1 = 0; div2 = 0; ni = 0;
    end
    disp(' ')
    for j=1:nse %loop para definir cada estacion
        se=['Estacion ' num2str(j)];
        disp(' ') 
        disp(se)
      %--- largueros sobre la estacion ---
        for i=1:n %loop para cada larguero 
             disp(' ')
             disp(['Cordon ' num2str(i)])
             a='Valor de Area: ';
             x='Coordenada en X: ';
             y='Coordenada en Y: ';
             aXs=input(x,'s');
             tf=strcmp(aXs,'idem');
             if (tf==1)&&(j>1) % si se ingreso idem copio datos de seccion anterior
                 Xs(j,:)=Xs(j-1,:);
                 Ys(j,:)=Ys(j-1,:);
                 if j~=nsec
                    As(j,i)=As(j-1,:);
                 end
                 break
             else 
                 Xs(j,i)=str2double(aXs);
                 Ys(j,i)=input(y);
                 if j~=nsec
                     As(j,i)=input(a);
                 end
             end
        save('Flow'); %autoguardado
        end %fin for i
        
      %% --- celdas ---
        if ce>1 % si se definio mas de una celda
        for i=1:ce-1 %loop para cada celda
            disp(' ')
            divnum=['Division ' num2str(i)]; 
            disp(divnum)
       %--- chapas divisoras ---
            if j==1 %defino estas condiciones en la primer estacion unicamente
                div1(1,i)=input('N� de cordon donde comienza: ');
                div2(1,i)=input('N� de cordon donde termina: ');
                ni(1,i)=input('Cantidad de cordones intermedios: ');
            end
            
       %--- cordones intermedios ---
            if ni(1,i)~=0 % si existen cordones en las divisiones de celdas
               for k=1:ni(1,i) %loop para definir cordones intermedios
                  disp(' ')
                  cordon=['cordon intermedio ' num2str(j)];
                  disp(cordon)
                  disp(' ')
                  x=input('Coordenada en X: ');
                  y=input('Coordenada en Y: ');
                  if j~=nsec 
                     a=input('Valor de Area: ');
                  end 
                  xii(j,:)=[xii x];
                  yii(j,:)=[yii y];
                  aii(j,:)=[aii a];
              end
            end % fin if de cordones intermedios 
        save('Flow'); % autoguardado
        end
        elseif ce==1
            ni=0; % asigno un valor a la variable para evitar errores en el caso monocelda
        end %fin if de cantidad de celdas
                   
     %--- coordenada z ---
        if j~=nsec
            disp(' ')
            long(1,j)=input('Longitud de la seccion: '); %long de seccion
            z(1,j+1)=sum(long); %ubiacion en z de la estacion
        end
    save('Flow'); %autoguardado
    end %fin loop de estaciones
disp(' ')
%--- espesores ---
nq=n+ce-1+sum(ni); % cantidad de chapas (=cant de largueros+1 por cada celda nueva+1 por cada larguero en divisiones de celda)
Ts=zeros(nse,nq); % espesores de chapas
espesor2=input('�Todas las chapas tienen el mismo espesor? [S/N]: ','s');
  %--- Chapas iguales ---
if (espesor2=='S')||(espesor2=='s') %si define que todas las chapas tienen el mismo espesor
    Ts1=1; %esta variable no se para que la defini
    Ts = input('Espesor de las chapas: '); 
    Ts=ones(nse,nq)*Ts; % mismo valor en todas las componentes 
  %--- Chapas distintas ---
elseif (espesor2=='N')||(espesor2=='n') %si no tienen mismo espesor
    espesor= input('�Todas las secciones tienen los mismos espesores? [S/N]: ','s');
    if (espesor=='S')||(espesor=='s') % si en cada seccion se repiten los espesores
        nesp=1; % variable para definir cuantas veces iterar
    elseif (espesor=='N')||(espesor=='n') % si no se repiten
        nesp=nse-1;
    end
    disp(' ')
    for i=1:nesp %loop para definir espesores
       disp(['Secci�n: ' num2str(i);]) 
       disp(' ')
       disp('Chapas exteriores')
       disp(' ')
       t1=input(['Espesor chapa ' num2str(i) ': ']);
       Ts(1,i)=tl;
    if ce>1 % si hay mas de una celda, defino chapas de divisiones
       disp('Chapas de divisiones')
       disp(' ')
       for k=1:ce-1 %loop para cada division
           disp(['Division ' num2str(k)])
           n1=n;
           for j=1:ni(1,k)+1 %loop por cada larguero
               n1=n1+1;
               t1=['Espesor chapa ' num2str(j) ': '];
               Ts(1,n1)=input(t1);
               disp(' ')
           end %fin loop por largueros
       end %fin loop por divisiones
    end %fin if de celdas
    save('Flow');
    end
    if (espesor=='S')||(espesor=='s') %si habia definido que todas las secciones tienen iguales chapas
        for i=2:nse
           Ts(i,:)=Ts(1,:); % copio los valores para cada seccion
        end
    end    
    
end
if nse==1
    Ts(2,:)=Ts(1,:); %agrego datos de la estacion virtual que cierra el cajon
end
    
 Xs=[Xs xii]; %adiciono valores de largueros en divisiones a los vectores
 Ys=[Ys yii]; %de datos de largueros
 As=[As aii]; %TODO: verificar dimensiones de xii,yii,aii
 if nse==1
     Xs(2,:)=Xs(1,:); %si solo se definio una estacion, se crea otra igual
     Ys(2,:)=Ys(1,:); %para convertirla en una viga de la longitud ingresada
 end
 clear se divnum tf cordon a x y espesor espesor2 n1 tl nesp
 save('Flow');
 clear nonzero
 NonZero; %Script que elimina filas de areas nulas
 Inicio; % fin de ingreso de geometria, regresa al menu principal
%% Modificar geometria
    case 2 %cambiar valores
   disp(' ')
   disp('--------------------') 
   disp('     Geometria')
   disp('--------------------')
   disp([' 1-Cantidad de estaciones: ' num2str(nse)]);
   disp([' 2-Cantidad de cordones: ' num2str(n)]);
   disp(' 3-Datos de celdas')
   disp(' ')
   disp(' 4-Cantidad de largueros en divisiones');
   disp(' 5-Longitud de secciones');
   disp(' 6-Valores en X de largueros')
   disp(' 7-Valores en Y de largueros')
   disp(' 8-Valores de areas de largueros')
   disp(' 9-Espesores de chapas')
   disp(' ')
   disp(' 0-Atras')
   disp(' ')
   changeGeom=input('Elija una opci�n: ');
   disp(' ')
   if changeGeom==0
       if Calculado==0 
           Inicio; %si aun no se calculo regreso al menu principal
       else
           PostCalculos;%si ya se calculo regreso al menu postcalculos
       end
   else
       CambiarGeom; % menu para cambiar geometria segun valor ingresado
   end
end %fin switch chooseGeom
