%secciones ahusadas
 
Jxx=zeros(1,nt); %inicializo vectores usados en el calculo
Jyy=zeros(1,nt);
Jxyy=zeros(1,nt);
Jx=zeros(2,1);
Jy=zeros(2,1);
Jxy=zeros(2,1);
dSa=zeros(1,nt);
S=zeros(2,nt);
dH=zeros(2,nt);
dV=zeros(2,nt);
Xc0=zeros(2,nt);
Yc0=zeros(2,nt);
Ab=zeros(2,nq);

At=sum(A); %Area total de largueros = suma de area de cada larguero

% Cg = [componente en x , componente en y   % de la 1� estacion
       %componente en x , componente en y]  % de la 2� estacion
Cg=[A*transpose(X(1,:))/At A*transpose(Y(1,:))/At;A*transpose(X(2,:))/At A*transpose(Y(2,:))/At];

for j=1:2
    for i=1:nt
      Xc0(j,i)=X(j,i)-Cg(j,1); %posiciones de largueros respecto del cg
      Yc0(j,i)=Y(j,i)-Cg(j,2);
      Jxx(1,i)=A(1,i)*(Yc0(j,i))^2;
      Jyy(1,i)=A(1,i)*(Xc0(j,i))^2;
      Jxyy(1,i)=A(1,i)*Xc0(j,i)*Yc0(j,i);
    end
    Jx(j,1)=sum(Jxx);
    Jy(j,1)=sum(Jyy);
    Jxy(j,1)=sum(Jxyy);
end

%% --- Areas equivalentes ---
% disp(' ')
% if Optim==0
%     Idealiz = input('Desea utilizar areas equivalentes para el calculo [S/N]: ','s');
% end
% if(strcmp(Idealiz,'S'))
%     AreasEq;
% end


%% --- Calcula 2� estacion ---

%Constantes Kij , i numero de cte, j numero de estacion
K11=(Mfpx*Jy(1,1)-Mfpy*Jxy(1,1))/(Jx(1,1)*Jy(1,1)-Jxy(1,1)^2);
K21=(Mfpy*Jx(1,1)-Mfpx*Jxy(1,1))/(Jx(1,1)*Jy(1,1)-Jxy(1,1)^2);
K12=((Mfpx+P(1,3)*lse)*Jy(2,1)-(Mfpy+P(1,1)*lse)*Jxy(2,1))/(Jx(2,1)*Jy(2,1)-Jxy(2,1)^2);
K22=((Mfpy+P(1,1)*lse)*Jx(2,1)-(Mfpx+P(1,3)*lse)*Jxy(2,1))/(Jx(2,1)*Jy(2,1)-Jxy(2,1)^2);

for i=1:nt %loop en cantidad de largueros
   lh=X(2,i)-X(1,i); %ahusamiento "del larguero"
   lv=Y(2,i)-Y(1,i);
   %esfuerzos sobre el larguero i en estacion 1 de la seccion
   S(1,i)=(K11*Yc0(1,i)+K21*Xc0(1,i))*A(1,i); % esfuerzo en z
   dH(1,i)=S(1,i)*lh/lse; % componentes transversales
   dV(1,i)=S(1,i)*lv/lse;
   %esfuerzos sobre el larguero i en estacion 2 de la seccion
   S(2,i)=(K12*Yc0(2,i)+K22*Xc0(2,i))*A(1,i);
   dH(2,i)=S(2,i)*lh/lse;
   dV(2,i)=S(2,i)*lv/lse;
   %deltaS /a
   dSa(1,i)=(S(2,i)-S(1,i))/lse;
end


%--- para multicelda ---
if ce>=2
    x0=Xc0(2,:);
    y0=Yc0(2,:);
    Celdas3;
    Celdas2;
    SistemaMulti;
 %--- defino longitudes para la correcion por qraya ---   
    l=zeros(1,nq);
    x2=[Xc0(2,n) Xc0(2,:) Xc0(2,:)];
    x21=[Xc0(1,n) Xc0(1,:) Xc0(1,:)];
    y2=[Yc0(2,n) Yc0(2,:) Yc0(2,:)];
    y21=[Yc0(1,n) Yc0(1,:) Yc0(1,:)];
    for i=1:n
         l(1,i)=((y21(1,i+1)-y21(1,i))^2+(x21(1,i+1)-x21(1,i))^2)^(1/2)/(((y2(1,i+1)-y2(1,i))^2+(x2(1,i+1)-x2(1,i))^2)^(1/2));
         %longitud de una chapa de la estacion 1 / long de la misma chapa en
         %la estacion 2
    end
    x0=Xc0(1,:);
    y0=Yc0(1,:);
    xy=max(ni);
    xce1=zeros(ce-1,xy+2); % posiciones de los largueros intermedios
    yce1=zeros(ce-1,xy+2);
    ni2=n;
    for i=1:ce-1 % loop por divisiones de celdas
        n1=div1(1,i); %larguero donde comienza la division
        n2=div2(1,i); %larguero donde termina la division
        nc=ni(1,i)+2;
        xce1(i,1)=x0(1,n1); % posiciones de larguero donde comienza
        xce1(i,nc)=x0(1,n2); % posiciones de larguero donde termina
        yce1(i,1)=y0(1,n1);
        yce1(i,nc)=y0(1,n2);
        if ni(1,i)~=0 % si exiten largueros intermedios en la division
            for j=1:ni(1,i)
                ni2=ni2+1;
                xce1(i,j+1)=x0(1,ni2); %posiciones de los largueros intermedios
                yce1(i,j+1)=y0(1,ni2);
            end
        end
    end
    k=n;
    for i=1:ce-1 % loop por cantidades de divisiones de celdas
        if ni(1,i)~=0 % si existen largueros intermedios
            for j=1:ni(1,i)+1
                k=k+1; %continua desde la chapa n (ultima chapa externa)
                l(1,k)=((xce1(i,j+1)-xce1(i,j))^2+(yce1(i,j+1)-yce1(i,j))^2)^(1/2)/(((xce(i,j+1)-xce(i,j))^2+(yce(i,j+1)-yce(i,j))^2)^(1/2)); 
                %longitud de una chapa de la estacion 1 / long de la misma chapa en
                %la estacion 2
            end
        else % si no existen largueros intermedios
            for j=1
                k=k+1;
                l(1,k)=((xce1(i,j+1)-xce1(i,j))^2+(yce1(i,j+1)-yce1(i,j))^2)^(1/2)/((xce(i,j+1)-xce(i,j))^2+(yce(i,j+1)-yce(i,j))^2)^(1/2);
            end
        end
    end
    for i=1:nq
        B(nt,i)=B(nt,i)/l(1,i); %corrijo ecuacion de momentos multiplicando cada componente 
        %por la correccion debido a ahusamiento en la chapa para calcular q
        %raya
        for j=nt+1:nq % correccion de ecuaciones de giro
            B(j,i) = B(j,i)/l(1,i);
        end
    end
    KH=zeros(1,nt);
    KV=zeros(1,nt);
    for i=1:nt
        KH(1,i)=-dH(2,i)*Yc0(2,i); % momento debido a componentes transversales
        KV(1,i)=dV(2,i)*Xc0(2,i); % de los esfuerzos en largueros
    end
    Bnh(nt,1)=Bnh(nt,1)+sum(KH)+sum(KV); 
    Q=B\Bnh; % solucion del sistema de ecuaciones
    q=transpose(Q);
%----------para una sola celda----------------
elseif ce==1
    Ab=zeros(2,n);
    x2=[Xc0(2,n) Xc0(2,:) Xc0(2,:)];
    x21=[Xc0(1,n) Xc0(1,:) Xc0(1,:)];
    y2=[Yc0(2,n) Yc0(2,:) Yc0(2,:)];
    y21=[Yc0(1,n) Yc0(1,:) Yc0(1,:)];
for i=1:n
    base=((y2(1,i+1)-y2(1,i))^2+(x2(1,i+1)-x2(1,i))^2)^(1/2);
    a=((x2(1,i+1))^2+(y2(1,i+1))^2);
    b=((x2(1,i))^2+(y2(1,i))^2)^(1/2);
    h=b*sin(acos((a-b^2-base^2)/(-2*b*base)));
    Ab(1,i)=base*h/2;
    base=((y21(1,i+1)-y21(1,i))^2+(x21(1,i+1)-x21(1,i))^2)^(1/2);
    a=((x21(1,i+1))^2+(y21(1,i+1))^2);
    b=((x21(1,i))^2+(y21(1,i))^2)^(1/2);
    h=b*sin(acos((a-b^2-base^2)/(-2*b*base)));
    Ab(2,i)=base*h/2;
end 
%ds2=zeros(1,n);
%K=zeros(1,n);
KH=zeros(1,n);
KV=zeros(1,n);
KA=zeros(1,n);
%ds1=[0 dSa];
l=zeros(1,n);
for i=1:n
    l(1,i)=((y21(1,i+1)-y21(1,i))^2+(x21(1,i+1)-x21(1,i))^2)^(1/2)/(((y2(1,i+1)-y2(1,i))^2+(x2(1,i+1)-x2(1,i))^2)^(1/2));
 %   for j=1:i
  %      ds2(1,j)=ds1(1,j);
  %     K(1,i)=l(1,i)*Ab(1,i)*sum(ds2);
 %  end
    KH(1,i)=-dH(2,i)*Yc0(2,i);
    KV(1,i)=-dV(2,i)*Xc0(2,i);
    KA(1,i)=l(1,i)*2*Ab(1,i);
end
% q=zeros(1,n);
B=zeros(n);
Bnh=zeros(n,1);
for i=1:n-1
    B(i,i)=-1;
    B(i,i+1)=1;
    Bnh(i,1)=dSa(1,i);
end
for i=1:n
    B(n,i)=KA(1,i);
end
Bnh(n,1)=(P(1,1)*(P(1,2)-Cg(2,2))+P(1,3)*(P(1,4)-Cg(2,1))-sum(KH)+sum(KV));
q=B\Bnh;
%q(1,1)=(P(1,1)*(P(1,2)-Cg(2,2))+P(1,3)*(P(1,4)-Cg(2,1))-sum(KH)-sum(KV)-2*sum(K))/(2*sum(KA));
%ds2=zeros(1,n);
%for i=2:n
%    ds2(1,i)=ds1(1,i);
%    q(1,i)=q(1,1)+sum(ds2);
%end
end %fin de if por cantidad de celdas
qraya=q;
q=zeros(2,nq);
for i=1:nq
    q(1,i)=qraya(i)/l(1,i); %mult por long de est 2/long de est 1
    q(2,i)=qraya(i)*l(1,i); %mulr pot long de est 1/long de est 2
end