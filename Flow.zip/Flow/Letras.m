%convertir numeros en letras para excel
switch numero
    case 1
        letra='A';
    case 2
        letra='B';
    case 3
        letra='C';
    case 4
        letra='D';
    case 5
        letra='E';
    case 6
        letra='F';
    case 7
        letra='G';
    case 8
        letra='H';
    case 9
        letra='I';
    case 10
        letra='J';
    case 11
        letra='K';
    case 12
        letra='L';
    case 13
        letra='M';
    case 14
        letra='N';
    case 15
        letra='O';
    case 16
        letra='P';
    case 17
        letra='Q';
    case 18
        letra='R';
    case 19
        letra='S';
    case 20
        letra='T';
    case 21
        letra='U';
    case 22
        letra='V';
    case 23
        letra='W';
    case 24
        letra='X';
    case 25
        letra='Y';
    case 26
        letra='Z';
    case 27
        letra='AA';
end