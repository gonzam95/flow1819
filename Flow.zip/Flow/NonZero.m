% Defino vectores y variables para omitir cordones con area nula en tablas
if exist('nonzero','var')==0
   nonzero=0;
   nnc=[];
   nnc1=[];
   for i=1:(n+sum(ni))
      if any(As(:,i))~=0;
          nonzero = nonzero+1;
          nnc(nonzero,1)=i;
          nnc1(i,1)=1;
      else
          nnc1(i,1)=0;
      end
   end
end
