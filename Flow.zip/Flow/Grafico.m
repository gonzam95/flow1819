%Graficos de vigas
switch GrafO
    case 1 % geometria mas esfuerzos - desde Resultados
        subplot(4,1,[2,3,4])
        plot3 (0,0,0,'Marker','none');
        hold on
        %--- largueros ---
        for i=1:nesp
           for j=1:nt
                xv=[Xs(i,j) Xs(i+1,j)];
                yv=[-Ys(i,j) -Ys(i+1,j)];
                zv=[z(1,i) z(1,i+1)];
                dsv=alldS(1,j,i);
                av=As(i,j);
                plot3(zv(1,1),allCg(i,1),-allCg(i,2),'xr')
                plot3(zv(1,2),allCg(i+1,1),-allCg(i+1,2),'xr')
                if and(dsv>0,av~=0) 
                    plot3 (zv,xv,yv,'LineWidth',2,'Color','blue');
                elseif and(dsv<0,av~=0)
                    plot3 (zv,xv,yv,'LineWidth',2,'Color','red');
                elseif and(dsv==0,av~=0)
                    plot3 (zv,xv,yv,'LineWidth',2,'Color','black');
                else
                    plot3 (zv,xv,yv,'LineStyle','--','LineWidth',1,'Color','black');
                end
                avtxt=['A' num2str(j)];
                text (zv(1,1),xv(1,1)+0.5,yv(1,1)+0.5,avtxt,'FontSize',9,'Color',[0.4 0.7 0.7]);

            end
        end
        %--- chapas ---
        kv=0;
        for i=1:nesp
           if (i==nesp), range = 1:2;
           else range = 1;
           end
           for u = range
               %--- externas ---
               kv=kv+1;
               Xgv=[Xs(kv,n) Xs(kv,:)];
%               Xgv(1,n+1)=Xgv(1,1);
               Ygv=-[Ys(kv,n) Ys(kv,:)];
%               Ygv(1,n+1)=Ygv(1,1);
           for j=1:n
             xv=[Xgv(1,j) Xgv(1,j+1)];
             yv=[Ygv(1,j) Ygv(1,j+1)];
             zv=[z(1,kv) z(1,kv)];
             z1=zv(1,1);
             x1=(xv(1)+xv(2))/2;
             y1=(yv(1)+yv(2))/2;
             qv=allq(u,j,i);
             if qv==0
                 plot3 (zv,xv,yv,'Color,''black','LineWidth',1);
             else
                 plot3 (zv,xv,yv,'Color',[1 0.5 0.5],'LineWidth',1.5);
%                  if abs(yv(1)-yv(2))>abs(xv(1)-xv(2))
%                     if yv(1,1)>yv(1,2)
%                        if qv<0
%                            plot3 (z1,x1,y1,'b','Marker','^','MarkerSize',7,'MarkerFaceColor','b');           
%                        elseif qv>0
%                            plot3 (z1,x1,y1,'b','Marker','v','MarkerSize',7,'MarkerFaceColor','b');           
%                        end
%                     else
%                         if qv>0
%                            plot3 (z1,x1,y1,'b','Marker','^','MarkerSize',7,'MarkerFaceColor','b');           
%                        elseif qv<0
%                            plot3 (z1,x1,y1,'b','Marker','v','MarkerSize',7,'MarkerFaceColor','b');           
%                        end
%                     end
% 
%                  elseif abs(yv(1)-yv(2))<abs(xv(1)-xv(2))
%                     if xv(1,1)<xv(1,2)
%                        if qv<0
%                            plot3 (z1,x1,y1,'b','Marker','<','MarkerSize',7,'MarkerFaceColor','b');           
%                        elseif qv>0
%                            plot3 (z1,x1,y1,'b','Marker','>','MarkerSize',7,'MarkerFaceColor','b');           
%                        end
%                     else
%                         if qv>0
%                            plot3 (z1,x1,y1,'b','Marker','<','MarkerSize',7,'MarkerFaceColor','b');           
%                        elseif qv<0
%                            plot3 (z1,x1,y1,'b','Marker','>','MarkerSize',7,'MarkerFaceColor','b');           
%                         end
%                     end

%                  end
             end
             if kv==1
                 qvtxt=['q' num2str(j)];
                 text(z1+0.5,x1+0.5,y1+0.5,qvtxt,'FontSize',9,'Color',[0.7 0.4 0.4]);
             end
           end
           %--- internas ---
           if ce>1
           nlar=n;
           qnum=n;
           for j=1:length(div1)
               clear Xgv Ygv
               Xgv(1)=Xs(kv,div1(j));
               Ygv(1)=-Ys(kv,div1(j));
               nlar2=1;
               nlar2=nlar2+1;
               if ni(j)~=0
                   for ij=1:ni(j)
                       nlar=nlar+1;
                       Xgv(nlar2)=Xs(kv,nlar);
                       Ygv(nlar2)=-Ys(kv,nlar);
                       nlar2=nlar2+1;
                   end
               end
               Xgv(nlar2)=Xs(kv,div2(j));
               Ygv(nlar2)=-Ys(kv,div2(j));
               for ij=1:length(Xgv)-1
                     xv=[Xgv(1,ij) Xgv(1,ij+1)];
                     yv=[Ygv(1,ij) Ygv(1,ij+1)];
                     zv=[z(1,kv) z(1,kv)];
                     z1=zv(1,1);
                     x1=(xv(1)+xv(2))/2;
                     y1=(yv(1)+yv(2))/2;
                     qv=allq(u,j,i);
                     if qv==0
                         plot3 (zv,xv,yv,'Color,''black','LineWidth',1);
                     else
                         plot3 (zv,xv,yv,'b','LineWidth',1.5);
%                          if abs(yv(1)-yv(2))>abs(xv(1)-xv(2))
%                             if yv(1,1)>yv(1,2)
%                                if qv<0
%                                    plot3 (z1,x1,y1,'b','Marker','^','MarkerSize',7,'MarkerFaceColor','b');           
%                                elseif qv>0
%                                    plot3 (z1,x1,y1,'b','Marker','v','MarkerSize',7,'MarkerFaceColor','b');           
%                                end
%                             else
%                                 if qv>0
%                                    plot3 (z1,x1,y1,'b','Marker','^','MarkerSize',7,'MarkerFaceColor','b');           
%                                elseif qv<0
%                                    plot3 (z1,x1,y1,'b','Marker','v','MarkerSize',7,'MarkerFaceColor','b');           
%                                end
%                             end
% 
%                          elseif abs(yv(1)-yv(2))<abs(xv(1)-xv(2))
%                             if xv(1,1)<xv(1,2)
%                                if qv<0
%                                    plot3 (z1,x1,y1,'b','Marker','<','MarkerSize',7,'MarkerFaceColor','b');           
%                                elseif qv>0
%                                    plot3 (z1,x1,y1,'b','Marker','>','MarkerSize',7,'MarkerFaceColor','b');           
%                                end
%                             else
%                                 if qv>0
%                                    plot3 (z1,x1,y1,'b','Marker','<','MarkerSize',7,'MarkerFaceColor','b');           
%                                elseif qv<0
%                                    plot3 (z1,x1,y1,'b','Marker','>','MarkerSize',7,'MarkerFaceColor','b');           
%                                 end
%                             end
%                          end
                     end
                             if kv==1
                                 qnum=qnum+1;
                                 qvtxt=['q' num2str(qnum)];
                                 text(z1+0.5,x1+0.5,y1+0.5,qvtxt,'FontSize',9,'Color',[0.7 0.4 0.4]);
                             end
                            
                            
                end
           end
           end
           end
        end
        hold off
        
    case 0 % solo geometria - desde inicio

        plot3 (0,0,0,'Marker','none');
        hold on
        if nse==1
            nesp=1;
        else
            nesp=nse-1;
        end
        nt=n+sum(ni); %num de largueros

        %--- Largueros ---
        for i=1:nesp
           for j=1:nt
                xv=[Xs(i,j) Xs(i+1,j)];
                yv=[-Ys(i,j) -Ys(i+1,j)];
                zv=[z(1,i) z(1,i+1)];
                av=As(i,j);
                if av==0
                    plot3 (zv,xv,yv,'LineStyle','--','LineWidth',1,'Color','blue');
                else
                    plot3 (zv,xv,yv,'LineWidth',2,'Color','blue');
                end
                avtxt=['A' num2str(j)];
                text (zv(1,1),xv(1,1)+0.5,yv(1,1)+0.5,avtxt,'FontSize',9,'Color',[0.4 0.7 0.7]);

            end
        end

        %--- chapas ---
        kv=0;
        for i=1:nesp+1
%            if (i==nesp)&&(i~=1), range = 1;
%            else range = 1:2;
%            end
%            for u = range
               %--- externas ---
               kv=kv+1;
               Xgv=[Xs(kv,n) Xs(kv,:)];
%               Xgv(1,n+1)=Xgv(1,1);
               Ygv=-[Ys(kv,n) Ys(kv,:)];
%               Ygv(1,n+1)=Ygv(1,1);
               for j=1:n
                 xv=[Xgv(1,j) Xgv(1,j+1)];
                 yv=[Ygv(1,j) Ygv(1,j+1)];
                 zv=[z(1,kv) z(1,kv)];
                 z1=zv(1,1);
                 x1=(xv(1)+xv(2))/2;
                 y1=(yv(1)+yv(2))/2;
                     plot3(zv,xv,yv,'Color','black','LineWidth',1);
                 if kv==1
                     qvtxt=['q' num2str(j)];
                     text(z1+0.5,x1+0.5,y1+0.5,qvtxt,'FontSize',9,'Color',[0.7 0.4 0.4]);
                 end
               end
               %--- internas ---
               if ce>1
               nlar=n;
               qnum=n;
               for j=1:length(div1)
                   clear Xgv Ygv
                   Xgv(1)=Xs(kv,div1(j));
                   Ygv(1)=-Ys(kv,div1(j));
                   nlar2=1;
                   nlar2=nlar2+1;
                   if ni(j)~=0
                       for ij=1:ni(j)
                           nlar=nlar+1;
                           Xgv(nlar2)=Xs(kv,nlar);
                           Ygv(nlar2)=-Ys(kv,nlar);
                           nlar2=nlar2+1;
                       end
                   end
                   Xgv(nlar2)=Xs(kv,div2(j));
                   Ygv(nlar2)=-Ys(kv,div2(j));
                   for ij=1:length(Xgv)-1
                     xv=[Xgv(1,ij) Xgv(1,ij+1)];
                     yv=[Ygv(1,ij) Ygv(1,ij+1)];
                     zv=[z(1,kv) z(1,kv)];
                     z1=zv(1,1);
                     x1=(xv(1)+xv(2))/2;
                     y1=(yv(1)+yv(2))/2;
                         plot3(zv,xv,yv,'Color','black','LineWidth',1);
                     if kv==1
                         qnum=qnum+1;
                         qvtxt=['q' num2str(qnum)];
                         text(z1+0.5,x1+0.5,y1+0.5,qvtxt,'FontSize',9,'Color',[0.7 0.4 0.4]);
                     end
                   end
               end
               end
%            end
        end

        hold off
end
        
        