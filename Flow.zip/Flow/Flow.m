% 'Flow' es un programa para calculo de estructuras semimonocasco que
%utiliza el metodo de areas idealizadas.
% Se busca un programa que permita calcular y optimizar estrucuturas
%semimonocasco de manera rapida y sencilla obteniendo resultados con poco
%error.
% Desarrollado por Joaquin Maldonado Larsen, como trabajo final, 
%en la Facultad de Ingenieria, Universidad Nacional de La Plata.

if exist('Calculado','var') %no reescribir datos si no se llego a calcular

    if exist('chooseGeom','var')==0
        aux = 1;
    else
        aux = 0;
    end

else aux = 1;
end
if aux==1
    clear
    Ts1=1;
    As=0;
    Xs=0;
    Ys=0;
    Ts=0;
    n=0;
    nse=0;
    nq=0;
    ni=0;
    ce=0;
    div1=0;
    div2=0;
    long=0;
    z=0;
    Mf = 0;
    Mt=0;
    Mfx=0;
    Mfy=0;
    chooseGeom=0;
    chooseCarga=0;
    materiales=0;
    Calculado=false;
    MSecciones=0;
end

Optim = 0; % determina si el calculo procede del menu de optimizacion
Optim1 = 'Toda la viga'; nOptim=0;% Necesario para "Optimizar"
Optim2 = 'Toda la viga'; nOptim2=0; % Necesario para "Optimizar"

Inicio; % menu principal

       



