% materiales=1 si ya se ingresaron datos de materiales
if materiales==1
    disp(' ')
    disp('--------------------') 
    disp(' Datos de material')
    disp('--------------------')
    disp(' ')
    disp('--- Largueros ---')
    disp(['Modulo de elasticidad: ' num2str(Eco)]);
    %disp(['Modulos de corte: ' num2str(Gco)]);
    disp(['Tensi�n admisible (sigma): ' num2str(Sigmaco)]);
    %disp(['Tensi�n admisible (tau): ' num2str(Tauco)]); %los largueros no
    %ven corte
    disp(' ')
    disp('--- Chapas ---')
    disp(['Modulo de elasticidad: ' num2str(Ech)]);
    %disp(['Modulo de corte: ' num2str(Gch)]); %TODO: verificar si uso G para algo
    %disp(['Tensi�n admisible (sigma): ' num2str(Sigmach)]); %las chapas no
    %ven axil
    disp(['Tensi�n admisible (tau): ' num2str(Tauch)]);
end

disp(' ')
disp('--------------------') 
disp(' Datos adicionales')
disp('--------------------')
disp(' ')
disp(' 1-Datos de materiales')
disp(' 2-Secciones de largueros')
disp(' 0-Atras')
disp(' ')
chooseMat=input('Elija una opci�n: ');

switch chooseMat
    case 1
        disp(' ')
        disp('---------------------') 
        disp('Material de largueros')
        disp('---------------------') 
        disp(' ')
        Eco=input('Modulo de elasticidad: ');
        %Gco=input('Modulo de corte: ');
        Sigmaco=input('Tensi�n admisible (sigma): ');
        %Tauco=input('Tensi�n admisible (tau): ');
        disp (' ')
        disp('--------------------') 
        disp('Material de chapa')
        disp('--------------------') 
        disp(' ')
        Ech=input('Modulo de elasticidad: ');
        %Gch=input('Modulo de corte: ');
        %Sigmach=input('Tensi�n admisible (sigma): ');
        Tauch=input('Tensi�n admisible (tau): ');
        materiales=1; %datos de materiales ingresados
        Inicio;
    case 2
        if(materiales==1), Secciones;
        else disp(' '); disp('Para los calculos realizados en este modulo se requieren datos del material.'); Material;
        end
        
    case 0
        if Calculado==0
            Inicio;
        elseif Calculado==1
            PostCalculos;
        end
end
    
    
    