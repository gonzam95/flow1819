%calculos para pandeo local de largueros
%se aplica metodo de secciones planas

%Momentos de inercia
Lprop=zeros(n,2); %Primer columna area total de la seccion, 2� momento de inercia
for k=1:n
    Ll=Dimensiones(k,:);
    Lt=Espesores(k,:);
    La=Ll.*Lt; %producto de longitud y espesor para cada capa
    Lprop(k,1)=sum(La); %suma de los productos = Area de la seccion
    Lcg=(La(1)*Ll(2)+La(2)*Ll(2)/2)/Lprop(k,1); %calculo cg de la seccion
    Lprop(k,2)=(Ll(1)*Lt(1)^3/12+La(1)*(Ll(2)-Lcg)^2)+(Lt(2)*Ll(2)^3/12+La(2)*(Lcg-Ll(2)/2)^2)+(Ll(3)*Lt(3)^3/12+La(3)*Lcg^2);
    % Momento de inercia (considera momentos propios y steiner)
end


nu=0.3; %coef de poisson
ks=4*pi^2/(12*(1-nu^2)); %coeficiente del metodo para placas intermedia
kf=0.43*pi^2/(12*(1-nu^2)); %coef del metodo para placas en extemos
for k=1:n
    sw=Seccion(k);
    switch sw
        case 'Z'
            Lscr=zeros(1,3);
            Lscr(1,1)=kf*Eco*(Espesores(k,1)/Dimensiones(k,1)); %tension critica de cada placa de la seccion
            Lscr(1,2)=ks*Eco*(Espesores(k,2)/Dimensiones(k,2));
            Lscr(1,3)=kf*Eco*(Espesores(k,3)/Dimensiones(k,3));
            if(Lscr(1,2)>Sigmaco)
                Lscr(1,2)=Sigmaco;
            end
            if(Lscr(1,1)>Lscr(1,2))
                Lscr(1,1)=Lscr(1,2);
            end
            if(Lscr(1,3)>Lscr(1,2))
                Lscr(1,3)=Lscr(1,2);
            end
            Sigmacr(k)=(Lscr(1,1)*Dimensiones(k,1)*Espesores(k,1)+Lscr(1,2)*Dimensiones(k,2)*Espesores(k,2)+Lscr(1,3)*Dimensiones(k,3)*Espesores(k,3))/Lprop(k,1);
            %tension critica de la seccion a partir de las tensiones de
            %cada placa


        case 'T'
            Lscr=zeros(1,3);
            Lscr(1,1)=kf*Eco*(Espesores(k,1)/Dimensiones(k,1)); %tension critica de cada placa de la seccion
            Lscr(1,2)=kf*Eco*(Espesores(k,2)/Dimensiones(k,2));
            Lscr(1,3)=kf*Eco*(Espesores(k,3)/Dimensiones(k,3));
            if(Lscr(1,2)>Sigmaco)
                Lscr(1,2)=Sigmaco;
            end
            if(Lscr(1,1)>Lscr(1,2))
                Lscr(1,1)=Lscr(1,2);
            end
            if(Lscr(1,3)>Lscr(1,2))
                Lscr(1,3)=Lscr(1,2);
            end
            Sigmacr(k)=(Lscr(1,1)*Dimensiones(k,1)*Espesores(k,1)+Lscr(1,2)*Dimensiones(k,2)*Espesores(k,2)+Lscr(1,3)*Dimensiones(k,3)*Espesores(k,3))/Lprop(k,1);
            
            
        case 'L'
            Lscr=zeros(1,2);
            Lscr(1,1)=kf*Eco*(Espesores(k,1)/Dimensiones(k,1));
            Lscr(1,2)=kf*Eco*(Espesores(k,2)/Dimensiones(k,2));
            if(Lscr(1,1)>Sigmaco)
                Lscr(1,1)=Sigmaco;
            end
            if(Lscr(1,2)>Sigmaco)
                Lscr(1,2)=Sigmaco;
            end
            Sigmacr(k)=(Lscr(1,1)*Dimensiones(k,1)*Espesores(k,1)+Lscr(1,2)*Dimensiones(k,2)*Espesores(k,2))/Lprop(k,1);


    end

    if PCritica(k)~=0
        Sigmacr(k) = PCritica(k)/LProp(k,1);
    end

end



