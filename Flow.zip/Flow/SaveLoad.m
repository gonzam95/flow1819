
cd('.\Estados')
disp(' ')
    
disp('Archivos guardados: ')
disp(' ')
ls
disp(' ')
disp(' Ingrese 0 (cero) para volver atras')
filename=input(' Nombre del archivo: ','s');
if filename~=0
    switch chooseFlow
    %% Guardar datos
        case {5,7} 
            clear Pref
            if (exist(filename,'file'))||(exist(strcat(filename,'.mat'),'file'))
                disp(' Ya existe una archivo guardado con ese nombre')
                auxsl = input(' �Desea sobreescribirlo? [1 0]: ');
                if auxsl==1
                    save(filename);
                    disp('--- Datos guardados ---')
                    disp(' ')
                end
            else
                save(filename);
                disp('--- Datos guardados ---')
                disp(' ')
            end

            

    %% Cargar datos
        case 8 
            save('Flow')
            try                 
                clear
                load('Flow','filename')
                load(filename);
                save('Flow')
                disp(' ')
                disp('--- Datos cargados ---')
            catch ME
                load('Flow')
                disp(' ')
                disp('No se pudo cargar el archivo solicitado.')
                disp(ME.message)
            end

    end
end

cd('../')
clear filename dir dir2
if Calculado==1
    PostCalculos;
elseif Calculado==0
    Inicio;
end
